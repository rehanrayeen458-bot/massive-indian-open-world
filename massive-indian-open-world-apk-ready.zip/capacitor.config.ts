import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.rehan.massiveindianopenworld',
  appName: 'Massive Indian Open World',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
