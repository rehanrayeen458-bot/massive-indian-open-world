# Massive Indian Open World — Android APK build

This project is configured to build a test APK using GitHub Actions. No computer is required, but a GitHub account and internet connection are needed.

## Phone-only steps

1. Extract this ZIP on your Android phone (Files app / ZArchiver).
2. Open https://github.com in Chrome and sign in or create an account.
3. Create a new **Public** repository, e.g. `massive-indian-open-world`.
4. Upload the *contents* of this extracted folder to the repository root. Make sure `.github/workflows/build-apk.yml` is included. If the GitHub mobile upload screen hides `.github`, use Chrome's **Desktop site** mode.
5. Open the repository's **Actions** tab.
6. Select **Build Android APK** from the left side, tap **Run workflow**, then confirm **Run workflow**.
7. Wait until the run completes successfully (green tick). Open that run and scroll to **Artifacts**.
8. Download `massive-indian-open-world-debug-apk`, extract the downloaded artifact ZIP, then tap `app-debug.apk` to install.
9. If Android asks, allow Chrome/Files to **Install unknown apps** for this installation, then install.

## Notes
- This creates a debug APK for testing, not a Play Store release.
- The project is a web-based React/Three.js game packaged in an Android WebView; performance depends on the phone.
- The GitHub Actions build requires internet access and can take several minutes.
