import * as THREE from 'three';
import {
  VEHICLES, ROADS, SPAWN,
  type CityDef, type VehicleKey, type VehicleSpec,
} from './data';
import {
  terrainHeight, createTerrain, createSea, createRivers,
  createClouds, createStars, createSunSprite,
} from './terrain';
import { createRoads, distanceToRoads, type RoadSegment } from './roads';
import {
  createCityLayer, createVegetation, createInteractableProp,
  getFacadeMaterial,
  type Interactable, type Collider,
} from './city';
import { buildVehicleMesh, type BuiltVehicle } from './vehicles';
import { Character } from './character';
import { Traffic } from './traffic';
import { GameAudio } from './audio';

export interface HudData {
  speedKmh: number;
  topSpeedKmh: number;
  score: number;
  distanceKm: number;
  timeLeft: number;
  weather: 'clear' | 'rain' | 'auto';
  rainIntensity: number;
  hour: number;
  discovered: number;
  total: number;
  nearest: { name: string; state: string; km: number; bearing: number } | null;
  inVehicle: boolean;
  offroad: boolean;
  handbrake: boolean;
  nearPrompt: string | null;
  vehicleName: string;
  characterName: string;
}

export interface GameResult {
  score: number;
  citiesFound: number;
  totalCities: number;
  distanceKm: number;
  topSpeedKmh: number;
  timePlayed: number;
}

export interface EngineOptions {
  mode: 'tour' | 'free';
  character: { skin: string; outfit: string; pants: string; hair: string; name: string };
  weatherMode: 'auto' | 'clear' | 'rain';
  onHud: (h: HudData) => void;
  onGameOver: (r: GameResult) => void;
  onToast: (msg: string, kind?: 'gold' | 'green' | 'red' | 'info') => void;
  onGarage: (open: boolean) => void;
  onDiscover: (city: CityDef) => void;
  onEscape: () => void;
}

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const damp = (a: number, b: number, l: number, dt: number) => a + (b - a) * (1 - Math.exp(-l * dt));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

const IS_TOUCH = typeof window !== 'undefined' && (window.matchMedia?.('(pointer: coarse)').matches || /Android|iPhone|iPad/i.test(navigator.userAgent));

class ParticleSystem {
  geo = new THREE.BufferGeometry();
  points: THREE.Points;
  max: number;
  pos: Float32Array;
  vel: Float32Array;
  life: Float32Array;
  cursor = 0;
  gravity: number;
  col?: Float32Array;

  constructor(max: number, size: number, color: string | null, gravity = -9, vertexColors = false) {
    this.max = max;
    this.gravity = gravity;
    this.pos = new Float32Array(max * 3);
    this.vel = new Float32Array(max * 3);
    this.life = new Float32Array(max);
    const positions = new Float32Array(max * 3);
    const colors = new Float32Array(max * 3);
    for (let i = 0; i < max; i++) positions[i * 3 + 1] = -9999;
    this.geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    if (vertexColors) {
      this.col = colors.fill(1) as Float32Array;
      this.geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    }
    const mat = new THREE.PointsMaterial({ size, transparent: true, opacity: 0.92, depthWrite: false, vertexColors, color: color ?? new THREE.Color(0xffffff) });
    this.points = new THREE.Points(this.geo, mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 12;
  }

  spawn(x: number, y: number, z: number, vx: number, vy: number, vz: number, life: number, color?: THREE.Color) {
    const i = this.cursor;
    this.cursor = (this.cursor + 1) % this.max;
    this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z;
    this.vel[i * 3] = vx; this.vel[i * 3 + 1] = vy; this.vel[i * 3 + 2] = vz;
    this.life[i] = life;
    const pos = this.geo.attributes.position.array as Float32Array;
    pos[i * 3] = x; pos[i * 3 + 1] = y; pos[i * 3 + 2] = z;
    if (this.col && color) {
      this.col[i * 3] = color.r; this.col[i * 3 + 1] = color.g; this.col[i * 3 + 2] = color.b;
    }
  }

  update(dt: number) {
    const pos = this.geo.attributes.position.array as Float32Array;
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) continue;
      this.life[i] -= dt;
      if (this.life[i] <= 0) { pos[i * 3 + 1] = -9999; continue; }
      this.vel[i * 3 + 1] += this.gravity * dt;
      this.pos[i * 3] += this.vel[i * 3] * dt;
      this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt;
      this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      pos[i * 3] = this.pos[i * 3]; pos[i * 3 + 1] = this.pos[i * 3 + 1]; pos[i * 3 + 2] = this.pos[i * 3 + 2];
    }
    this.geo.attributes.position.needsUpdate = true;
    if (this.col) this.geo.attributes.color.needsUpdate = true;
  }
}

export class Engine {
  private renderer!: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera!: THREE.PerspectiveCamera;
  private canvas!: HTMLCanvasElement;
  private opts: EngineOptions;
  private clock = new THREE.Clock();
  private raf = 0;
  private disposed = false;

  private segments: RoadSegment[] = [];
  private citiesLayer!: ReturnType<typeof createCityLayer>;
  private colliders: Collider[] = [];
  private traffic!: Traffic;
  private clouds!: THREE.Group;
  private stars!: THREE.Points;
  private sunSprite!: THREE.Sprite;
  private sun!: THREE.DirectionalLight;
  private hemi!: THREE.HemisphereLight;

  private character!: Character;
  private vehicle!: BuiltVehicle;
  private vehicleKey: VehicleKey = 'swift';
  private vehicleColor = '#c0c8cc';
  private vehicleSpec: VehicleSpec = VEHICLES.find((v) => v.key === 'swift')!;
  private heading = Math.PI / 2;
  private v = 0;
  private steering = 0;
  private wheelSpin = 0;
  private inVehicle = false;
  private walkPhase = 0;
  private jumpY = 0;
  private jumpVy = 0;
  private grounded = true;
  private footHeading = Math.PI / 2;

  private camYaw = Math.PI / 2;
  private camDistIdx = 1;
  private shake = 0;

  private rainIntensity = 0;
  private rainTarget = 0;
  private rainMode: 'auto' | 'clear' | 'rain';
  private rainSchedule = 75;
  private rainIsRaining = false;
  private timeOfDay = 9.5 / 24;
  private gameTime = 0;
  private timeLeft = 0;
  private score = 0;
  private distance = 0;
  private topSpeed = 0;
  private discovered = new Set<string>();
  private petrolVisited = new Set<string>();
  private garageOpen = false;
  private paused = false;
  private finished = false;
  private glowPool: THREE.Mesh | null = null;

  private keys = new Set<string>();
  private touch = { steer: 0, throttle: 0, brake: 0, handbrake: false, move: { x: 0, y: 0 }, jump: false };

  private dust!: ParticleSystem;
  private confetti!: ParticleSystem;
  private rain!: THREE.Points;
  private rainPos!: Float32Array;

  private interactables: Interactable[] = [];
  private hudAcc = 0;
  private minimapCanvas: HTMLCanvasElement | null = null;
  private minimapBg: HTMLCanvasElement | null = null;

  private audio = new GameAudio();
  private cloudsMat: THREE.SpriteMaterial | null = null;
  private fog!: THREE.FogExp2;

  constructor(canvas: HTMLCanvasElement, opts: EngineOptions) {
    this.canvas = canvas;
    this.opts = opts;
    this.rainMode = opts.weatherMode;
    this.timeLeft = opts.mode === 'tour' ? 600 : -1;

    this.initRenderer();
    this.initWorld();
    this.initActors();
    this.initParticles();
    this.initMinimap();
    this.bindInput();
    this.emitHud();
  }

  private initRenderer() {
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: !IS_TOUCH, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, IS_TOUCH ? 1.35 : 1.75));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    this.camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.5, 42000);
    this.camera.position.set(SPAWN.x - 26, 26, SPAWN.z + 26);
    this.scene.fog = new THREE.FogExp2('#c7d8e4', 0.00042);
    this.fog = this.scene.fog;
    this.scene.background = new THREE.Color('#87b5d6');
  }

  private initWorld() {
    this.scene.add(createTerrain());
    this.scene.add(createSea());
    this.scene.add(createRivers());

    const roads = createRoads();
    this.scene.add(roads.group);
    this.segments = roads.segments;

    this.citiesLayer = createCityLayer(this.segments);
    this.scene.add(this.citiesLayer.group);
    this.colliders = [...this.citiesLayer.colliders];

    for (const zone of this.citiesLayer.zones) {
      if (!zone.city.featured) continue;
      const props = [
        { type: 'petrol' as const, dx: 170, dz: -120 },
        { type: 'garage' as const, dx: -190, dz: 150 },
      ];
      for (const p of props) {
        const x = zone.x + p.dx, z = zone.z + p.dz;
        const prop = createInteractableProp(p.type);
        prop.position.set(x, terrainHeight(x, z) + 0.2, z);
        this.scene.add(prop);
        if (p.type === 'garage') this.colliders.push({ x, z, hw: 9.5, hd: 6.5, h: 8 });
        this.interactables.push({ x, z, radius: 30, type: p.type, name: `${zone.city.name} ${p.type === 'petrol' ? 'Petrol Pump' : 'Garage'}`, used: false });
      }
    }

    this.scene.add(createVegetation(this.segments));

    this.clouds = createClouds(16);
    this.scene.add(this.clouds);
    const firstCloud = this.clouds.children[0] as THREE.Sprite;
    this.cloudsMat = firstCloud.material as THREE.SpriteMaterial;

    this.stars = createStars();
    this.scene.add(this.stars);

    this.sunSprite = createSunSprite();
    this.scene.add(this.sunSprite);

    this.sun = new THREE.DirectionalLight('#fff2dd', 2.6);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(IS_TOUCH ? 1024 : 2048, IS_TOUCH ? 1024 : 2048);
    this.sun.shadow.camera.left = -120;
    this.sun.shadow.camera.right = 120;
    this.sun.shadow.camera.top = 120;
    this.sun.shadow.camera.bottom = -120;
    this.sun.shadow.camera.near = 1;
    this.sun.shadow.camera.far = 900;
    this.sun.shadow.bias = -0.0006;
    this.sun.shadow.normalBias = 0.6;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);

    this.hemi = new THREE.HemisphereLight('#cfe5ff', '#7a6a4f', 0.85);
    this.scene.add(this.hemi);

    this.traffic = new Traffic();
    this.scene.add(this.traffic.group);
  }

  private initActors() {
    this.character = new Character({
      skin: this.opts.character.skin,
      outfit: this.opts.character.outfit,
      pants: this.opts.character.pants,
      hair: this.opts.character.hair,
    });
    this.character.group.position.set(SPAWN.x, terrainHeight(SPAWN.x, SPAWN.z), SPAWN.z);
    this.scene.add(this.character.group);

    this.vehicle = buildVehicleMesh(this.vehicleSpec, this.vehicleColor);
    this.vehicle.group.position.set(SPAWN.x + 3.6, terrainHeight(SPAWN.x + 3.6, SPAWN.z) + 0.05, SPAWN.z + 2.6);
    this.vehicle.group.rotation.y = this.heading;
    this.scene.add(this.vehicle.group);
    if (this.vehicle.rider) this.vehicle.rider.visible = false;
    this.attachGlowPool();
  }

  private attachGlowPool() {
    if (this.glowPool) { this.vehicle.group.remove(this.glowPool); this.glowPool = null; }
    const L = this.vehicleSpec.length;
    const glow = new THREE.Mesh(
      new THREE.CircleGeometry(L * 0.62, 24),
      new THREE.MeshBasicMaterial({ color: '#ffe6b0', transparent: true, opacity: 0.0, depthWrite: false, blending: THREE.AdditiveBlending })
    );
    glow.rotation.x = -Math.PI / 2;
    glow.position.set(0, 0.12, L * 0.65);
    glow.name = 'headlightglow';
    this.vehicle.group.add(glow);
    this.glowPool = glow;
  }

  private initParticles() {
    this.dust = new ParticleSystem(260, 7, '#c9b48a', -5.5);
    this.scene.add(this.dust.points);
    this.confetti = new ParticleSystem(320, 6, null, -20, true);
    this.scene.add(this.confetti.points);

    const N = IS_TOUCH ? 650 : 1100;
    this.rainPos = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      this.rainPos[i * 3] = (Math.random() - 0.5) * 220;
      this.rainPos[i * 3 + 1] = Math.random() * 95 - 10;
      this.rainPos[i * 3 + 2] = (Math.random() - 0.5) * 220;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(this.rainPos, 3));
    const mat = new THREE.PointsMaterial({ color: '#bcd4e8', size: 0.55, transparent: true, opacity: 0.5, depthWrite: false });
    this.rain = new THREE.Points(geo, mat);
    this.rain.frustumCulled = false;
    this.rain.visible = false;
    this.scene.add(this.rain);
  }

  private initMinimap() {
    this.minimapBg = document.createElement('canvas');
    this.minimapBg.width = 256; this.minimapBg.height = 256;
    const ctx = this.minimapBg.getContext('2d')!;
    const img = ctx.createImageData(256, 256);
    const d = img.data;
    for (let y = 0; y < 256; y++) {
      for (let x = 0; x < 256; x++) {
        const wx = (x / 256 - 0.5) * 36000;
        const wz = (y / 256 - 0.5) * 36000;
        const h = terrainHeight(wx, wz);
        const i = (y * 256 + x) * 4;
        if (h < 1) { d[i] = 22; d[i + 1] = 56; d[i + 2] = 92; }
        else if (h < 60) { d[i] = 96; d[i + 1] = 128; d[i + 2] = 74; }
        else if (h < 180) { d[i] = 152; d[i + 1] = 168; d[i + 2] = 90; }
        else if (h < 380) { d[i] = 148; d[i + 1] = 132; d[i + 2] = 100; }
        else { d[i] = 214; d[i + 1] = 214; d[i + 2] = 228; }
        d[i + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
  }

  private onAnyPointer = () => this.audio.ensure();
  private bindInput() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.onResize);
    window.addEventListener('pointerdown', this.onAnyPointer);
  }
  private unbindInput() {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('pointerdown', this.onAnyPointer);
  }
  private onResize = () => {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  };
  private onKeyDown = (e: KeyboardEvent) => {
    if (e.repeat) return;
    this.keys.add(e.code);
    if (e.code === 'KeyE') this.pressInteract();
    if (e.code === 'KeyC') this.cycleCamera();
    if (e.code === 'Escape') this.opts.onEscape();
    if (e.code === 'KeyR') this.audio.ensure();
  };
  private onKeyUp = (e: KeyboardEvent) => this.keys.delete(e.code);

  setMinimapCanvas(el: HTMLCanvasElement | null) { this.minimapCanvas = el; }
  setTouch(t: Partial<typeof this.touch>) { Object.assign(this.touch, t); }

  cycleCamera() {
    this.camDistIdx = (this.camDistIdx + 1) % 3;
    this.audio.click();
  }

  pressInteract() {
    if (this.garageOpen || this.paused) return;
    const pos = this.inVehicle ? this.vehicle.group.position : this.character.group.position;
    for (const it of this.interactables) {
      const d = Math.hypot(pos.x - it.x, pos.z - it.z);
      if (d < it.radius) {
        if (it.type === 'garage') { this.openGarage(); return; }
        if (!it.used) {
          it.used = true;
          this.score += 100;
          this.petrolVisited.add(it.name);
          this.audio.coin();
          this.opts.onToast(`+100 Petrol pump · ${it.name}`, 'gold');
          return;
        }
      }
    }
    if (this.inVehicle) { this.exitVehicle(); return; }
    const d = this.character.group.position.distanceTo(this.vehicle.group.position);
    if (d < 5.5) this.enterVehicle();
  }

  enterVehicle() {
    if (this.inVehicle) return;
    this.inVehicle = true;
    this.character.group.visible = false;
    if (this.vehicle.rider) this.vehicle.rider.visible = true;
    this.audio.whoosh();
  }

  exitVehicle() {
    if (!this.inVehicle) return;
    this.inVehicle = false;
    const vpos = this.vehicle.group.position;
    const perp = this.heading + Math.PI / 2;
    const off = 3.3;
    this.character.group.position.set(
      vpos.x + Math.sin(perp) * off,
      terrainHeight(vpos.x, vpos.z) + 0.1,
      vpos.z + Math.cos(perp) * off
    );
    this.jumpY = 0; this.grounded = true;
    this.footHeading = this.heading;
    this.v = 0; this.steering = 0;
    this.character.group.visible = true;
    if (this.vehicle.rider) this.vehicle.rider.visible = false;
    this.audio.whoosh();
  }

  setPlayerVehicle(key: VehicleKey, color: string) {
    const same = key === this.vehicleKey && color === this.vehicleColor;
    if (same) { this.closeGarage(); return; }
    this.vehicleKey = key;
    this.vehicleColor = color;
    this.vehicleSpec = VEHICLES.find((v) => v.key === key)!;
    const oldGroup = this.vehicle.group;
    const oldPos = oldGroup.position.clone();
    const oldRot = oldGroup.rotation.y;
    this.scene.remove(oldGroup);
    this.disposeGroup(oldGroup);
    this.vehicle = buildVehicleMesh(this.vehicleSpec, color);
    this.vehicle.group.position.copy(oldPos);
    this.vehicle.group.rotation.y = oldRot;
    this.scene.add(this.vehicle.group);
    if (this.vehicle.rider) this.vehicle.rider.visible = this.inVehicle;
    this.attachGlowPool();
    this.v = 0; this.steering = 0;
    this.audio.click();
    this.opts.onToast(`${this.vehicleSpec.name} selected`, 'green');
    this.closeGarage();
  }

  private closeGarage() {
    this.garageOpen = false;
    this.opts.onGarage(false);
  }

  private openGarage() {
    if (this.garageOpen) return;
    this.garageOpen = true;
    this.v = 0;
    this.audio.click();
    this.opts.onGarage(true);
  }

  closeGaragePublic() { this.closeGarage(); }
  setPaused(p: boolean) { this.paused = p; }
  setWeatherMode(m: 'auto' | 'clear' | 'rain') { this.rainMode = m; this.audio.ensure(); }
  setMuted(m: boolean) { this.audio.setMuted(m); }
  ensureAudio() { this.audio.ensure(); }
  getVehicleState() { return { key: this.vehicleKey, color: this.vehicleColor, spec: this.vehicleSpec }; }
  getIsGarageOpen() { return this.garageOpen; }

  private disposeGroup(group: THREE.Object3D) {
    group.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        (o.geometry as THREE.BufferGeometry)?.dispose?.();
        const m = o.material as THREE.Material | THREE.Material[];
        if (Array.isArray(m)) m.forEach((x) => x.dispose());
        else m?.dispose?.();
      }
    });
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.unbindInput();
    this.audio.dispose();
    this.scene.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        (o.geometry as THREE.BufferGeometry)?.dispose?.();
        const m = o.material as THREE.Material | THREE.Material[];
        if (Array.isArray(m)) m.forEach((x) => x.dispose());
        else m?.dispose?.();
      }
    });
    this.renderer.dispose();
  }

  start() {
    this.clock.start();
    this.loop();
  }

  private loop = () => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    if (!this.paused && !this.garageOpen) this.update(dt);
    this.render(dt);
  };

  private update(dt: number) {
    this.gameTime += dt;
    if (this.timeLeft > 0) {
      this.timeLeft -= dt;
      if (this.timeLeft <= 0) {
        this.timeLeft = 0;
        this.finish();
        return;
      }
    }

    this.timeOfDay = (this.timeOfDay + dt / 600) % 1;
    this.updateWeather(dt);

    const kmh = Math.abs(this.v) * 3.6;
    this.topSpeed = Math.max(this.topSpeed, kmh);
    if (this.inVehicle && kmh > 180) this.score += 2.5 * dt;

    if (this.inVehicle) this.updateVehicle(dt);
    else this.updateFoot(dt);

    const playerPos = this.inVehicle ? this.vehicle.group.position : this.character.group.position;
    this.traffic.update(dt, playerPos, Math.abs(this.v));

    this.dust.update(dt);
    this.confetti.update(dt);
    this.updateRain(dt);

    if (this.clouds) {
      for (const c of this.clouds.children) {
        c.position.x += dt * 3.2;
        if (c.position.x > 24000) c.position.x = -24000;
      }
    }

    this.checkDiscovery();

    this.hudAcc += dt;
    if (this.hudAcc > 0.13) {
      this.hudAcc = 0;
      this.emitHud();
    }
  }

  private updateWeather(dt: number) {
    if (this.rainMode === 'clear') this.rainTarget = 0;
    else if (this.rainMode === 'rain') this.rainTarget = 1;
    else {
      this.rainSchedule -= dt;
      if (this.rainSchedule <= 0) {
        this.rainIsRaining = !this.rainIsRaining;
        this.rainTarget = this.rainIsRaining ? 1 : 0;
        this.rainSchedule = this.rainIsRaining ? (35 + Math.random() * 35) : (85 + Math.random() * 70);
        if (this.rainIsRaining) this.opts.onToast('Cloud cover building — rain incoming', 'info');
        else this.opts.onToast('Skies clearing', 'info');
        this.audio.setRain(this.rainIsRaining);
      }
    }
    this.rainIntensity = damp(this.rainIntensity, this.rainTarget, 0.35, dt);
    if (this.rainMode === 'clear' && this.rainIntensity < 0.05) this.audio.setRain(false);
  }

  private checkDiscovery() {
    const pos = this.inVehicle ? this.vehicle.group.position : this.character.group.position;
    for (const zone of this.citiesLayer.zones) {
      const city = zone.city;
      if (this.discovered.has(city.id)) continue;
      const d = Math.hypot(pos.x - zone.x, pos.z - zone.z);
      if (d < zone.radius) {
        this.discovered.add(city.id);
        this.score += 500;
        const y = terrainHeight(pos.x, pos.z) + 2;
        this.burstConfetti(pos.x, y + 4, pos.z);
        this.audio.chime();
        this.opts.onDiscover(city);
      }
    }
  }

  private finish() {
    if (this.finished) return;
    this.finished = true;
    this.audio.silenceEngine();
    this.audio.setRain(false);
    this.opts.onGameOver({
      score: Math.floor(this.score),
      citiesFound: this.discovered.size,
      totalCities: this.citiesLayer.zones.length,
      distanceKm: this.distance / 1000,
      topSpeedKmh: Math.round(this.topSpeed),
      timePlayed: this.gameTime,
    });
  }

  private burstConfetti(x: number, y: number, z: number) {
    const colors = ['#ff9933', '#f5f5f2', '#138808', '#f5b544', '#e14545'];
    for (let i = 0; i < 170; i++) {
      const ang = Math.random() * Math.PI * 2;
      const sp = 6 + Math.random() * 14;
      const c = new THREE.Color(colors[Math.floor(Math.random() * colors.length)]);
      this.confetti.spawn(x, y, z, Math.cos(ang) * sp, 9 + Math.random() * 12, Math.sin(ang) * sp, 1.6 + Math.random() * 1.4, c);
    }
  }

  private updateVehicle(dt: number) {
    const v = this.vehicle;
    const pos = v.group.position;
    const spec = this.vehicleSpec;
    const throttleIn = this.keys.has('KeyW') || this.keys.has('ArrowUp') ? 1 : this.touch.throttle;
    const brakeIn = this.keys.has('KeyS') || this.keys.has('ArrowDown') ? 1 : this.touch.brake;
    const handbrake = this.keys.has('Space') || this.touch.handbrake;
    const steerIn = (this.keys.has('KeyA') || this.keys.has('ArrowLeft') ? -1 : 0) + (this.keys.has('KeyD') || this.keys.has('ArrowRight') ? 1 : 0) + this.touch.steer;

    const vTop = spec.topSpeed / 3.6;
    const accel = spec.accel / 3.6;

    const hAhead = terrainHeight(pos.x + Math.sin(this.heading) * 4, pos.z + Math.cos(this.heading) * 4);
    const hBehind = terrainHeight(pos.x - Math.sin(this.heading) * 4, pos.z - Math.cos(this.heading) * 4);
    const grade = (hAhead - hBehind) / 8;

    const distRoad = distanceToRoads(pos.x, pos.z, this.segments);
    const offroad = distRoad > 22;

    if (throttleIn > 0) {
      const headroom = Math.max(0.14, 1 - Math.abs(this.v) / vTop);
      this.v += accel * throttleIn * headroom * dt;
    } else {
      this.v -= Math.sign(this.v) * Math.min(Math.abs(this.v), 5.2 * dt);
    }
    if (brakeIn > 0) {
      if (this.v > 0.6) this.v -= Math.min(this.v, 26 * dt);
      else this.v = Math.max(this.v - 9 * dt, -16);
    }
    this.v -= this.v * (offroad ? 0.42 : 0.075) * dt;
    if (offroad) this.v -= this.v * 0.32 * dt;
    if (handbrake) this.v -= this.v * 1.9 * dt;
    this.v -= grade * 9.3 * dt * (this.v >= 0 ? 1 : -0.5);

    const target = clamp(steerIn, -1, 1);
    this.steering = damp(this.steering, target, target === 0 ? 5.5 : 6.5, dt);
    const speedAbs = Math.abs(this.v);
    const turnAuthority = clamp(speedAbs / 9, 0, 1) * (handbrake ? 2.9 : 1.85) * (1 - Math.min(speedAbs / vTop, 1) * 0.42);
    this.heading += this.steering * turnAuthority * dt * Math.sign(this.v || 1);

    const oldX = pos.x, oldZ = pos.z;
    pos.x += Math.sin(this.heading) * this.v * dt;
    pos.z += Math.cos(this.heading) * this.v * dt;

    const maxR = 17300;
    const r = Math.hypot(pos.x, pos.z);
    if (r > maxR) {
      pos.x *= maxR / r; pos.z *= maxR / r;
      this.v *= 0.5;
    }

    const hC = terrainHeight(pos.x, pos.z);
    const hSide1 = terrainHeight(pos.x + Math.cos(this.heading) * 2.4, pos.z - Math.sin(this.heading) * 2.4);
    const hSide2 = terrainHeight(pos.x - Math.cos(this.heading) * 2.4, pos.z + Math.sin(this.heading) * 2.4);
    pos.y = hC + 0.05;
    const pitch = Math.atan2(hAhead - hBehind, 8) * 0.9;
    const roll = Math.atan2(hSide1 - hSide2, 4.8) * 0.8;
    v.group.rotation.x = -pitch;
    v.group.rotation.z = roll;
    v.group.rotation.y = this.heading;

    // collider collisions
    const radius = spec.class === 'heavy' || spec.class === 'bus' ? 4.6 : 3.4;
    for (const c of this.colliders) {
      const dx = pos.x - clamp(pos.x, c.x - c.hw, c.x + c.hw);
      const dz = pos.z - clamp(pos.z, c.z - c.hd, c.z + c.hd);
      const d2 = dx * dx + dz * dz;
      if (d2 < radius * radius) {
        const d = Math.sqrt(d2);
        if (d > 0.001) {
          const push = radius - d;
          pos.x += (dx / d) * push;
          pos.z += (dz / d) * push;
        } else {
          const ox = c.hw + radius - Math.abs(pos.x - c.x);
          const oz = c.hd + radius - Math.abs(pos.z - c.z);
          if (ox < oz) pos.x += (pos.x > c.x ? ox : -ox);
          else pos.z += (pos.z > c.z ? oz : -oz);
        }
        this.collided(Math.abs(this.v), new THREE.Vector3(pos.x, pos.y, pos.z));
      }
    }

    // traffic collision
    for (const o of this.traffic.vehicles) {
      const p = o.built.group.position;
      const d = Math.hypot(p.x - pos.x, p.z - pos.z);
      if (d < 5.4) {
        const nx = (pos.x - p.x) / Math.max(d, 0.001);
        const nz = (pos.z - p.z) / Math.max(d, 0.001);
        pos.x += nx * (5.4 - d) * 0.5;
        pos.z += nz * (5.4 - d) * 0.5;
        this.collided(Math.abs(this.v) + 3, new THREE.Vector3(pos.x, pos.y, pos.z));
      }
    }

    const ddx = pos.x - oldX, ddz = pos.z - oldZ;
    const moved = Math.hypot(ddx, ddz);
    if (moved > 0.001) {
      this.distance += moved;
      this.score += moved * 0.12;
    }

    this.wheelSpin += this.v * dt * 1.9;
    for (const w of this.vehicle.wheels) w.rotation.x = this.wheelSpin % (Math.PI * 2);
    for (const w of this.vehicle.frontWheels) w.rotation.y = this.steering * 0.38;

    v.body.rotation.z = damp(v.body.rotation.z, -this.steering * Math.min(Math.abs(this.v) / 45, 1) * 0.055, 6, dt);
    v.body.rotation.x = damp(v.body.rotation.x, throttleIn * 0.02 - brakeIn * 0.03, 6, dt);

    // dust
    if (Math.abs(this.v) > 8 && (offroad || handbrake || (brakeIn > 0 && Math.abs(this.v) > 12))) {
      if (Math.random() < (offroad ? 34 : 18) * dt) {
        for (let i = 0; i < 3; i++) {
          const ang = this.heading + Math.PI + (Math.random() - 0.5) * 0.8;
          const px = pos.x + Math.sin(ang) * (spec.length * 0.38);
          const pz = pos.z + Math.cos(ang) * (spec.length * 0.38);
          this.dust.spawn(px, pos.y + 0.7 + Math.random() * 0.5, pz, Math.sin(ang) * (2 + Math.random() * 2), 1.6 + Math.random() * 1.4, Math.cos(ang) * (2 + Math.random() * 2), 0.8 + Math.random() * 0.7);
        }
      }
    }

    this.audio.setEngine(Math.min(1, Math.abs(this.v) / Math.max(1, spec.topSpeed / 3.6)), throttleIn);
    this.camYaw = damp(this.camYaw, this.heading, 7.5, dt);
  }

  private collided(speed: number, at: THREE.Vector3) {
    if (speed < 2.2) return;
    this.shake = Math.min(1.0, speed / 32);
    this.v *= 0.42;
    this.audio.thud(Math.min(1, speed / 40));
    for (let i = 0; i < 14; i++) {
      const ang = Math.random() * Math.PI * 2;
      this.dust.spawn(at.x, at.y + 1.2, at.z, Math.cos(ang) * 5, 2.5 + Math.random() * 3, Math.sin(ang) * 5, 0.5 + Math.random() * 0.4);
    }
  }

  private updateFoot(dt: number) {
    const pos = this.character.group.position;
    let mx = (this.keys.has('KeyD') || this.keys.has('ArrowRight') ? 1 : 0) - (this.keys.has('KeyA') || this.keys.has('ArrowLeft') ? 1 : 0) + this.touch.move.x;
    let mz = (this.keys.has('KeyW') || this.keys.has('ArrowUp') ? 1 : 0) - (this.keys.has('KeyS') || this.keys.has('ArrowDown') ? 1 : 0) + this.touch.move.y;
    const rawLen = Math.hypot(mx, mz);
    const len = Math.min(rawLen, 1);
    const run = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') || rawLen > 0.88;
    const speed = (run ? 10.6 : 5.6) * clamp(0.55 + 0.45 * len, 0.45, 1);
    const camYaw = this.camYaw;
    const sin = Math.sin(camYaw), cos = Math.cos(camYaw);
    const fx = sin, fz = cos;                      // forward
    const rx = -cos, rz = sin;                     // screen-right
    const wmX = fx * mz + rx * mx;
    const wmZ = fz * mz + rz * mx;

    if (len > 0.01) {
      const nx = wmX / Math.max(len, 1), nz = wmZ / Math.max(len, 1);
      pos.x += nx * speed * dt;
      pos.z += nz * speed * dt;
      this.footHeading = Math.atan2(nx, nz);
      this.character.group.rotation.y = damp(this.character.group.rotation.y, this.footHeading, 12, dt);
      this.walkPhase += dt * (run ? 13.5 : 8.6);
      this.character.animate(run ? 'run' : 'walk', this.walkPhase);
      const moved = speed * dt;
      this.distance += moved;
      this.score += moved * 0.05;
    } else {
      this.character.animate('idle', this.walkPhase);
    }

    if ((this.keys.has('Space') || this.touch.jump) && this.grounded) {
      this.jumpVy = 6.6;
      this.grounded = false;
      this.touch.jump = false;
      this.character.poseJump();
    }
    if (!this.grounded) {
      this.jumpVy -= 22 * dt;
      this.jumpY += this.jumpVy * dt;
      if (this.jumpY <= 0) { this.jumpY = 0; this.grounded = true; }
    }

    for (const c of this.colliders) {
      const dx = pos.x - clamp(pos.x, c.x - c.hw, c.x + c.hw);
      const dz = pos.z - clamp(pos.z, c.z - c.hd, c.z + c.hd);
      const d2 = dx * dx + dz * dz;
      if (d2 < 0.45) {
        const d = Math.sqrt(d2);
        if (d > 0.001) { pos.x += (dx / d) * (0.67 - d) * 0.9; pos.z += (dz / d) * (0.67 - d) * 0.9; }
      }
    }

    const r = Math.hypot(pos.x, pos.z);
    if (r > 17300) { pos.x *= 17300 / r; pos.z *= 17300 / r; }

    const gy = terrainHeight(pos.x, pos.z);
    pos.y = gy + this.jumpY + 0.02;
    if (this.grounded) this.audio.silenceEngine();
    this.camYaw = damp(this.camYaw, this.footHeading, 2.6, dt);
  }

  private updateRain(dt: number) {
    const cond = this.rainIntensity > 0.05 || this.rainMode === 'rain';
    this.rain.visible = cond;
    if (!cond) return;
    const cam = this.camera.position;
    const N = this.rainPos.length / 3;
    const fallSpeed = 30 + this.rainIntensity * 22;
    for (let i = 0; i < N; i++) {
      this.rainPos[i * 3 + 1] -= fallSpeed * dt;
      this.rainPos[i * 3] += dt * 4.5;
      if (this.rainPos[i * 3 + 1] < -12) {
        this.rainPos[i * 3 + 1] = 60 + Math.random() * 30;
        this.rainPos[i * 3] = (Math.random() - 0.5) * 220;
        this.rainPos[i * 3 + 2] = (Math.random() - 0.5) * 220;
      }
    }
    this.rain.position.set(cam.x, cam.y, cam.z);
    this.rain.geometry.attributes.position.needsUpdate = true;
    (this.rain.material as THREE.PointsMaterial).opacity = 0.24 + this.rainIntensity * 0.3;
  }

  private emitHud() {
    const pos = this.inVehicle ? this.vehicle.group.position : this.character.group.position;
    const kmh = Math.abs(this.v) * 3.6;
    let nearest: CityDef | null = null;
    let best = Infinity;
    for (const zone of this.citiesLayer.zones) {
      if (this.discovered.has(zone.city.id)) continue;
      const d = Math.hypot(pos.x - zone.x, pos.z - zone.z);
      if (d < best) { best = d; nearest = zone.city; }
    }
    let nearestInfo: HudData['nearest'] = null;
    if (nearest) {
      const dx = nearest.x - pos.x;
      const dz = nearest.z - pos.z;
      const angle = Math.atan2(dx, dz);
      nearestInfo = { name: nearest.name, state: nearest.state, km: best / 1000, bearing: angle - this.camYaw };
    }

    let nearPrompt: string | null = null;
    for (const it of this.interactables) {
      const d = Math.hypot(pos.x - it.x, pos.z - it.z);
      if (d < it.radius) {
        if (it.type === 'garage') nearPrompt = `Enter ${it.name}`;
        else nearPrompt = it.used ? it.name : `Refill · ${it.name}`;
        break;
      }
    }

    const hour = this.timeOfDay * 24;

    this.opts.onHud({
      speedKmh: kmh,
      topSpeedKmh: Math.round(this.topSpeed),
      score: Math.floor(this.score),
      distanceKm: this.distance / 1000,
      timeLeft: this.timeLeft,
      weather: this.rainMode,
      rainIntensity: this.rainIntensity,
      hour,
      discovered: this.discovered.size,
      total: this.citiesLayer.zones.length,
      nearest: nearestInfo,
      inVehicle: this.inVehicle,
      offroad: this.inVehicle ? distanceToRoads(pos.x, pos.z, this.segments) > 22 : false,
      handbrake: this.keys.has('Space') || this.touch.handbrake,
      nearPrompt,
      vehicleName: this.vehicleSpec.name,
      characterName: this.opts.character.name,
    });
  }

  private render(dt: number) {
    const pos = this.inVehicle ? this.vehicle.group.position : this.character.group.position;
    const hour = (this.timeOfDay * 24) % 24;
    const elevation = Math.sin(((hour - 6) / 12) * Math.PI);
    const dayFactor = clamp(elevation * 2.4 + 0.35, 0, 1);
    const nightFactor = 1 - dayFactor;

    // sky
    const daySky = new THREE.Color('#79b1de');
    const duskSky = new THREE.Color('#e58a4e');
    const dawnSky = new THREE.Color('#f0b46a');
    const nightSky = new THREE.Color('#070b1f');
    const duskAmount = clamp(1 - Math.abs(elevation) * 2.6, 0, 1);
    const sky = daySky.clone().lerp(nightSky, nightFactor);
    if (elevation > -0.15 && elevation < 0.5) sky.lerp(elevation > 0.12 ? dawnSky : duskSky, duskAmount * 0.8);
    if (this.rainIntensity > 0.02) sky.lerp(new THREE.Color('#46526b'), this.rainIntensity * 0.55);
    this.scene.background = sky;
    this.fog.color.copy(sky).lerp(new THREE.Color('#d8c8a8'), 0.18);
    this.fog.density = 0.00042 * (1 - this.rainIntensity * 0.4) + this.rainIntensity * 0.00078 + nightFactor * 0.00028;

    // sun
    const angle = ((hour - 6) / 24) * Math.PI * 2;
    const sunDir = new THREE.Vector3(Math.cos(angle), Math.max(Math.sin(angle), 0.02), 0.35).normalize();
    const sunIntensity = clamp(elevation * 3.2, 0, 3.0);
    this.sun.intensity = this.rainIntensity > 0.5 ? sunIntensity * 0.42 : sunIntensity;
    this.sun.position.copy(sunDir.multiplyScalar(320).add(pos));
    this.sun.target.position.copy(pos);
    this.sun.color.setHSL(0.09, 0.85 * (1 - dayFactor * 0.55), lerp(0.56, 0.95, dayFactor));
    this.hemi.intensity = lerp(0.14, 0.9, dayFactor);
    this.hemi.color.setHSL(0.58, 0.32, lerp(0.18, 0.66, dayFactor));
    this.hemi.groundColor.setHSL(0.09, 0.28, lerp(0.12, 0.5, dayFactor));

    const starsMat = this.stars.material as THREE.PointsMaterial;
    starsMat.opacity = nightFactor * 0.9;

    this.sunSprite.position.copy(sunDir.clone().multiplyScalar(16500).add(pos));
    (this.sunSprite.material as THREE.SpriteMaterial).opacity = clamp(elevation * 3, 0, 1) * (1 - this.rainIntensity * 0.88);
    (this.sunSprite.material as THREE.SpriteMaterial).color.setHSL(0.1, 0.7, lerp(0.72, 0.96, dayFactor));

    if (this.cloudsMat) {
      this.cloudsMat.opacity = 0.34 + this.rainIntensity * 0.5;
      this.cloudsMat.color.setHSL(0.6, 0.05, lerp(1.0, 0.58, this.rainIntensity));
    }

    const facadeMat = getFacadeMaterial();
    if (facadeMat) facadeMat.emissiveIntensity = nightFactor * 1.35;

    const headOn = nightFactor > 0.45;
    this.vehicle.headlightMat.emissiveIntensity = headOn ? 2.8 : 0.65;
    this.vehicle.tailMat.emissiveIntensity = 1.1;
    if (this.glowPool) {
      (this.glowPool.material as THREE.MeshBasicMaterial).opacity = headOn ? 0.34 : 0.0;
    }

    // camera
    const dist = this.inVehicle ? [11, 16, 24][this.camDistIdx] : [5.6, 8.4, 13][this.camDistIdx];
    const camY = Math.max(pos.y + (this.inVehicle ? 3.6 + dist * 0.24 : 2.0), terrainHeight(pos.x, pos.z) + 2.2);
    const desired = new THREE.Vector3(
      pos.x - Math.sin(this.camYaw) * dist,
      camY,
      pos.z - Math.cos(this.camYaw) * dist
    );
    const terrainAtCam = terrainHeight(desired.x, desired.z) + 1.5;
    desired.y = Math.max(desired.y, terrainAtCam);
    this.camera.position.x = damp(this.camera.position.x, desired.x, 6.2, dt);
    this.camera.position.y = damp(this.camera.position.y, desired.y, 5.4, dt);
    this.camera.position.z = damp(this.camera.position.z, desired.z, 6.2, dt);

    const look = new THREE.Vector3(pos.x + Math.sin(this.camYaw) * 7, pos.y + (this.inVehicle ? 1.9 : 1.6), pos.z + Math.cos(this.camYaw) * 7);

    if (this.shake > 0.001) {
      this.shake *= Math.exp(-6.5 * dt);
      const s = this.shake * 1.5;
      this.camera.position.x += (Math.random() - 0.5) * s;
      this.camera.position.y += (Math.random() - 0.5) * s * 0.7;
      look.x += (Math.random() - 0.5) * s;
      look.y += (Math.random() - 0.5) * s * 0.6;
    }
    this.camera.lookAt(look);

    this.renderer.render(this.scene, this.camera);
    this.drawMinimap(pos);
  }

  private drawMinimap(pos: THREE.Vector3) {
    if (!this.minimapCanvas) return;
    const ctx = this.minimapCanvas.getContext('2d');
    if (!ctx) return;
    const W = this.minimapCanvas.width, H = this.minimapCanvas.height;
    const scale = W / 36000;
    ctx.clearRect(0, 0, W, H);
    if (this.minimapBg) ctx.drawImage(this.minimapBg, 0, 0, W, H);
    ctx.strokeStyle = 'rgba(240,230,200,0.38)';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    for (const road of ROADS) {
      ctx.beginPath();
      road.pts.forEach((p, i) => {
        const x = (p[0] + 18000) * scale;
        const y = (p[1] + 18000) * scale;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.stroke();
    }
    for (const zone of this.citiesLayer.zones) {
      const x = (zone.x + 18000) * scale;
      const y = (zone.z + 18000) * scale;
      const isFound = this.discovered.has(zone.city.id);
      ctx.fillStyle = isFound ? '#22c55e' : '#f5b544';
      ctx.strokeStyle = 'rgba(10,12,24,0.9)';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(x, y, zone.city.featured ? 4.4 : 3.2, 0, Math.PI * 2);
      ctx.fill(); ctx.stroke();
    }
    const px = (pos.x + 18000) * scale;
    const py = (pos.z + 18000) * scale;
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(Math.PI - (this.inVehicle ? this.heading : this.character.group.rotation.y));
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#0b0e1a';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, -7);
    ctx.lineTo(5.2, 5.6);
    ctx.lineTo(0, 2.6);
    ctx.lineTo(-5.2, 5.6);
    ctx.closePath();
    ctx.fill(); ctx.stroke();
    ctx.restore();
  }
}
