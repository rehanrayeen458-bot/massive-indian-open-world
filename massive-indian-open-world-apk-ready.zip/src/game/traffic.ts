import * as THREE from 'three';
import { ROADS, VEHICLES, type VehicleKey } from './data';
import { buildVehicleMesh, type BuiltVehicle } from './vehicles';
import { terrainHeight } from './terrain';

interface RoadPath {
  pts: [number, number][];
  cum: number[];
  total: number;
}

function buildPath(pts: [number, number][]): RoadPath {
  const cum = [0];
  for (let i = 1; i < pts.length; i++) {
    cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  }
  return { pts, cum, total: cum[cum.length - 1] };
}

function evalPath(path: RoadPath, s: number, out: { x: number; z: number; ang: number }) {
  const { pts, cum, total } = path;
  const clamped = Math.max(0, Math.min(total, s));
  let i = 0;
  while (i < cum.length - 1 && cum[i + 1] < clamped) i++;
  const t = (clamped - cum[i]) / Math.max(1e-6, cum[i + 1] - cum[i]);
  const dx = pts[i + 1][0] - pts[i][0], dz = pts[i + 1][1] - pts[i][1];
  out.x = pts[i][0] + dx * t;
  out.z = pts[i][1] + dz * t;
  out.ang = Math.atan2(dx, dz);
  out.x = out.x; // keep
  return out;
}

export interface TrafficVehicle {
  built: BuiltVehicle;
  path: RoadPath;
  s: number;
  speed: number;
  targetSpeed: number;
  bottom: number;
  dir: 1 | -1;
  lane: number;
  wheelSpin: number;
}

const TRAFFIC_POOL: VehicleKey[] = ['swift', 'bmw', 'creta', 'fortuner', 'innova', 'audi', 'thar', 'swift', 'creta', 'mercedes', 'fortuner', 'swift', 'enfield', 'swift', 'thar', 'creta'];

export class Traffic {
  group = new THREE.Group();
  vehicles: TrafficVehicle[] = [];

  constructor() {
    this.group.name = 'traffic';
    // build paths
    const paths = ROADS.map((r) => buildPath(r.pts));
    let seed = 11;
    const rand = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };

    const perRoad = [3, 2, 2, 3, 2, 2, 4, 2, 2, 3, 2, 2, 2, 2, 2, 2, 1, 2];
    let vi = 0;
    paths.forEach((path, ri) => {
      const n = perRoad[ri] ?? 2;
      for (let i = 0; i < n; i++) {
        const pool = TRAFFIC_POOL[(vi * 3 + ri) % TRAFFIC_POOL.length];
        const spec = VEHICLES.find((v) => v.key === pool)!;
        const color = this.pickColor(rand);
        const built = buildVehicleMesh(spec, color);
        const dir: 1 | -1 = i % 2 === 0 ? 1 : -1;
        const lane = dir === 1 ? -3.4 : 3.4;
        const total = path.total;
        const s = rand() * total;
        const speedKmh = 58 + rand() * 42;
        const speedMs = speedKmh / 3.6;
        this.vehicles.push({
          built, path, s, speed: speedMs, targetSpeed: speedMs, bottom: 0, dir, lane, wheelSpin: 0,
        });
        this.group.add(built.group);
        vi++;
      }
    });
    this.setInitialTransforms();
  }

  private pickColor(rand: () => number) {
    const colors = ['#d8d5ce', '#141a22', '#e0b73c', '#3a6ea8', '#8c3a3a', '#dfe3e6', '#4a5d3a', '#c98f2e', '#5b5f6b', '#a34a1e'];
    return colors[Math.floor(rand() * colors.length)];
  }

  private setInitialTransforms() {
    for (const v of this.vehicles) this.applyTransform(v, 0);
  }

  private applyTransform(v: TrafficVehicle, dt: number) {
    const out = { x: 0, z: 0, ang: 0 };
    evalPath(v.path, v.s, out);
    // lane offset perpendicular
    const heading = out.ang + (v.dir === 1 ? 0 : Math.PI);
    const nx = Math.cos(heading), nz = -Math.sin(heading);
    const px = out.x + nx * v.lane, pz = out.z + nz * v.lane;
    const y = terrainHeight(px, pz);
    v.built.group.position.set(px, y + 0.05, pz);
    v.built.group.rotation.y = heading;
    if (dt > 0) {
      v.wheelSpin += v.speed * dt * 1.9;
      for (const w of v.built.wheels) w.rotation.x = v.wheelSpin % (Math.PI * 2);
    }
  }

  update(dt: number, playerPos: THREE.Vector3 | null, playerSpeed: number) {
    for (const v of this.vehicles) {
      // slow near player if ahead
      let target = v.targetSpeed;
      if (playerPos) {
        const out = { x: 0, z: 0, ang: 0 };
        evalPath(v.path, v.s, out);
        const heading = out.ang + (v.dir === 1 ? 0 : Math.PI);
        let ax = 0, az = 0;
        if (v.dir === 1) { ax = Math.sin(heading); az = Math.cos(heading); } else { ax = -Math.sin(heading); az = -Math.cos(heading); }
        const aheadX = out.x + ax * 26, aheadZ = out.z + az * 26;
        const d = Math.hypot(playerPos.x - aheadX, playerPos.z - aheadZ);
        if (d < 30 && Math.abs(playerSpeed) > 2) {
          target = Math.min(target, 6 + v.bottom); // brake
        }
      }
      v.speed += Math.sign(target - v.speed) * Math.min(Math.abs(target - v.speed), 9 * dt);
      v.speed = Math.max(3, v.speed);
      v.s += v.speed * dt * v.dir;
      if (v.s < 0) v.s = v.path.total;
      if (v.s > v.path.total) v.s = 0;
      this.applyTransform(v, dt);
    }
  }

  dispose() {
    this.group.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        (o.geometry as THREE.BufferGeometry)?.dispose?.();
        const m = o.material as THREE.Material | THREE.Material[];
        if (Array.isArray(m)) m.forEach((x) => x.dispose());
        else m?.dispose?.();
      }
    });
  }
}
