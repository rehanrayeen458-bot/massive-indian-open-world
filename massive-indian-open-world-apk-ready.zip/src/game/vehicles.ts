import * as THREE from 'three';
import type { VehicleSpec } from './data';

let plateTexture: THREE.CanvasTexture | null = null;
export function getPlateTexture() {
  if (plateTexture) return plateTexture;
  const cnv = document.createElement('canvas');
  cnv.width = 256; cnv.height = 64;
  const ctx = cnv.getContext('2d')!;
  ctx.fillStyle = '#f7f7f2';
  ctx.fillRect(0, 0, 256, 64);
  ctx.strokeStyle = '#141414'; ctx.lineWidth = 5;
  ctx.strokeRect(3, 3, 250, 58);
  ctx.fillStyle = '#141414';
  ctx.font = 'bold 34px Arial';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText('DL 01 AB 4521', 128, 34);
  plateTexture = new THREE.CanvasTexture(cnv);
  plateTexture.colorSpace = THREE.SRGBColorSpace;
  return plateTexture;
}

function glassMat() {
  return new THREE.MeshStandardMaterial({ color: '#0d141c', roughness: 0.12, metalness: 0.85 });
}
function tireMat() {
  return new THREE.MeshStandardMaterial({ color: '#17181c', roughness: 0.95 });
}
function rimMat() {
  return new THREE.MeshStandardMaterial({ color: '#c8ccd4', roughness: 0.25, metalness: 0.9 });
}

function makeWheel(r: number, w: number) {
  const group = new THREE.Group();
  const tire = new THREE.Mesh(new THREE.CylinderGeometry(r, r, w, 14), tireMat());
  tire.rotation.z = Math.PI / 2;
  tire.castShadow = true;
  const rim = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.52, r * 0.52, w + 0.04, 10), rimMat());
  rim.rotation.z = Math.PI / 2;
  group.add(tire, rim);
  return group;
}

function paintMaterial(color: string, rough = 0.32) {
  return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: 0.65 });
}

export interface BuiltVehicle {
  group: THREE.Group;
  wheels: THREE.Group[];
  frontWheels: THREE.Group[];
  body: THREE.Group;
  headlightMat: THREE.MeshStandardMaterial;
  tailMat: THREE.MeshStandardMaterial;
  rider?: THREE.Group;
}

export function buildVehicleMesh(spec: VehicleSpec, color: string): BuiltVehicle {
  const g = new THREE.Group();
  const body = new THREE.Group();
  const paint = paintMaterial(color);
  const glass = glassMat();
  const plate = getPlateTexture();
  const headMat = new THREE.MeshStandardMaterial({ color: '#fff8e0', emissive: '#fff2c8', emissiveIntensity: 0.6, roughness: 0.3 });
  const tailMat = new THREE.MeshStandardMaterial({ color: '#ff2b2b', emissive: '#c00e2e', emissiveIntensity: 0.7, roughness: 0.3 });

  const L = spec.length, W = spec.width;
  const wheels: THREE.Group[] = [];
  const frontWheels: THREE.Group[] = [];

  const addPlate = (y: number, z: number, rotX = 0) => {
    const p = new THREE.Mesh(
      new THREE.PlaneGeometry(0.95, 0.24),
      new THREE.MeshBasicMaterial({ map: plate, toneMapped: false })
    );
    p.position.set(0, y, z);
    p.rotation.x = rotX;
    body.add(p);
  };

  const classType = spec.class;

  if (classType === 'bike') {
    // Royal Enfield style adventure bike
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.3, L * 0.72), paint);
    frame.position.set(0, 0.62, 0.1);
    frame.castShadow = true;
    const tank = new THREE.Mesh(new THREE.SphereGeometry(0.34, 12, 10), paint);
    tank.scale.set(0.8, 0.55, 1.35);
    tank.position.set(0, 0.85, 0.55);
    tank.castShadow = true;
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.14, 0.9), new THREE.MeshStandardMaterial({ color: '#1a1a1a', roughness: 0.9 }));
    seat.position.set(0, 0.82, -0.45);
    const cyl = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.2, 0.34, 10), new THREE.MeshStandardMaterial({ color: '#9aa0a8', roughness: 0.4, metalness: 0.8 }));
    cyl.position.set(0, 0.6, 0.35);
    const hoop = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.045, 8, 16, Math.PI), paint);
    hoop.position.set(0, 1.05, 0.78);
    hoop.rotation.x = Math.PI / 2;
    hoop.rotation.z = 0;
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.14, 0.1), new THREE.MeshStandardMaterial({ color: '#111', emissive: '#ffedc0', emissiveIntensity: 1.1 }));
    head.position.set(0, 0.98, 0.88);
    const wl = makeWheel(0.34, 0.13); wl.position.set(0, 0.34, 0.92);
    const wr = makeWheel(0.34, 0.13); wr.position.set(0, 0.34, -0.92);
    wheels.push(wl, wr);
    body.add(frame, tank, seat, cyl, hoop, head, wl, wr);
    // rider
    const rider = new THREE.Group();
    const rBody = new THREE.Mesh(new THREE.CapsuleGeometry(0.16, 0.5, 4, 8), new THREE.MeshStandardMaterial({ color: '#2b3a4a', roughness: 0.8 }));
    rBody.position.set(0, 1.28, -0.35);
    rBody.rotation.x = 0.25;
    const rHead = new THREE.Mesh(new THREE.SphereGeometry(0.13, 10, 8), new THREE.MeshStandardMaterial({ color: '#caa17a', roughness: 0.7 }));
    rHead.position.set(0, 1.66, -0.15);
    const helm = new THREE.Mesh(new THREE.SphereGeometry(0.17, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.55), new THREE.MeshStandardMaterial({ color: '#f0f0f0', roughness: 0.3 }));
    helm.position.copy(rHead.position); helm.position.y += 0.03;
    rider.add(rBody, rHead, helm);
    rider.userData.seat = true;
    body.add(rider);
    addPlate(0.45, -1.06);

    g.add(body);
    return { group: g, wheels, frontWheels: [wl], body, headlightMat: headMat, tailMat, rider };
  }

  const isBus = classType === 'bus';
  const isTruck = classType === 'heavy' || classType === 'bus';

  // ─── BODY ───
  let bodyH = 0.62;          // lower box
  let cabinH = 0.52;
  let bodyY = 0.55;

  if (isBus) {
    const full = new THREE.Mesh(new THREE.BoxGeometry(W, 2.7, L), paint);
    full.position.set(0, 1.75, 0);
    full.castShadow = true;
    body.add(full);
    // cabin glass band
    const band = new THREE.Mesh(new THREE.BoxGeometry(W + 0.06, 0.85, L * 0.52), glass);
    band.position.set(0, 2.25, L * 0.22);
    body.add(band);
    // window strip along sides
    const strip = new THREE.Mesh(new THREE.BoxGeometry(W + 0.06, 0.5, L * 0.8), glass);
    strip.position.set(0, 2.05, -L * 0.1);
    body.add(strip);
    addPlate(0.6, L / 2 + 0.05);
  } else if (isTruck && spec.key === 'truck') {
    // cabin
    const cab = new THREE.Mesh(new THREE.BoxGeometry(W, 1.7, 2.1), paint);
    cab.position.set(0, 1.35, L / 2 - 1.35);
    cab.castShadow = true;
    body.add(cab);
    const windshield = new THREE.Mesh(new THREE.BoxGeometry(W - 0.24, 0.62, 0.06), glass);
    windshield.position.set(0, 1.78, L / 2 - 0.28);
    body.add(windshield);
    // trailer box
    const trailer = new THREE.Mesh(new THREE.BoxGeometry(W + 0.1, 2.6, L - 2.6), new THREE.MeshStandardMaterial({ color: '#e9e5da', roughness: 0.75, metalness: 0.25 }));
    trailer.position.set(0, 1.75, -0.7);
    trailer.castShadow = true;
    body.add(trailer);
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(W + 0.14, 0.5, L - 2.7), new THREE.MeshStandardMaterial({ color: color, roughness: 0.4, metalness: 0.6 }));
    stripe.position.set(0, 2.55, -0.7);
    body.add(stripe);
    addPlate(0.62, L / 2 + 0.05);
  } else {
    // sedan / suv / city
    const suv = spec.class === 'suv';
    bodyH = suv ? 0.66 : (classType === 'city' ? 0.52 : 0.58);
    bodyY = suv ? 0.78 : 0.62;
    const lower = new THREE.Mesh(new THREE.BoxGeometry(W, bodyH, L), paint);
    lower.position.set(0, bodyY, 0);
    lower.castShadow = true;
    body.add(lower);
    // rounded nose via scaled half-box
    const nose = new THREE.Mesh(new THREE.BoxGeometry(W * 0.94, bodyH * 0.62, L * 0.22), paint);
    nose.position.set(0, bodyY - 0.04, L * 0.5 + L * 0.03);
    body.add(nose);
    // cabin
    cabinH = suv ? 0.78 : 0.52;
    const cabinW = suv ? W * 0.9 : W * 0.82;
    const cabinL = suv ? L * 0.52 : L * 0.5;
    const cabinZ = suv ? -L * 0.05 : -L * 0.03;
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(cabinW, cabinH, cabinL), glass);
    cabin.position.set(0, bodyY + bodyH * 0.5 + cabinH * 0.5 - 0.04, cabinZ);
    cabin.castShadow = true;
    body.add(cabin);
    // A/B/C pillars hint
    const roof = new THREE.Mesh(new THREE.BoxGeometry(cabinW * 0.94, 0.1, cabinL * 0.86), paint);
    roof.position.set(0, bodyY + bodyH * 0.5 + cabinH - 0.02, cabinZ);
    roof.castShadow = true;
    body.add(roof);
    if (suv) {
      // roof rack
      const rack = new THREE.Mesh(new THREE.BoxGeometry(cabinW * 0.7, 0.09, cabinL * 0.62), new THREE.MeshStandardMaterial({ color: '#1d1d1f', roughness: 0.6 }));
      rack.position.set(0, roof.position.y + 0.1, cabinZ);
      body.add(rack);
    }
    addPlate(0.82, L / 2 + 0.04);
    addPlate(0.82, -L / 2 - 0.04);
    // mirrors
    for (const s of [-1, 1]) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.12, 0.2), paint);
      m.position.set(s * (W / 2 + 0.12), bodyY + bodyH * 0.4, L * 0.18);
      body.add(m);
    }
    // grille
    const grille = new THREE.Mesh(new THREE.BoxGeometry(W * 0.7, 0.14, 0.06), new THREE.MeshStandardMaterial({ color: '#111', roughness: 0.4, metalness: 0.8 }));
    grille.position.set(0, bodyY + 0.02, L / 2 + 0.02);
    body.add(grille);
  }

  // ─── lights ───
  const lightZ = (isBus || spec.key === 'truck') ? L / 2 + 0.02 : L / 2 + 0.06;
  for (const s of [-1, 1]) {
    const hl = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.16, 0.08), headMat);
    hl.position.set(s * (W * 0.3), (isBus ? 1.15 : (classType === 'suv' ? 0.95 : 0.78)), lightZ);
    body.add(hl);
    const tl = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.14, 0.08), tailMat);
    tl.position.set(s * (W * 0.3), (isBus ? 1.1 : (classType === 'suv' ? 0.95 : 0.78)), -L / 2 - 0.05);
    body.add(tl);
  }

  // ─── wheels ───
  const wheelR = isBus ? 0.62 : isTruck ? 0.66 : spec.class === 'suv' ? 0.5 : 0.42;
  const wheelW = isTruck ? 0.4 : spec.class === 'suv' ? 0.34 : 0.28;
  const wheelY = wheelR + 0.05;
  const insetZ = L / 2 - (isTruck ? 2.3 : spec.class === 'suv' ? 1.35 : 1.05);
  const lx = W / 2 - 0.06;
  const placeWheel = (z: number, side: number, front: boolean) => {
    const w = makeWheel(wheelR, wheelW);
    w.position.set(side * lx, wheelY, z);
    wheels.push(w);
    if (front) frontWheels.push(w);
    body.add(w);
  };
  if (isTruck) {
    placeWheel(insetZ, -1, true); placeWheel(insetZ, 1, true);
    placeWheel(-L / 2 + 1, -1, false); placeWheel(-L / 2 + 1, 1, false);
    placeWheel(-L / 2 + 2.2, -1, false); placeWheel(-L / 2 + 2.2, 1, false);
  } else if (isBus) {
    placeWheel(L / 2 - 2.4, -1, true); placeWheel(L / 2 - 2.4, 1, true);
    placeWheel(-L / 2 + 1.8, -1, false); placeWheel(-L / 2 + 1.8, 1, false);
  } else {
    placeWheel(insetZ, -1, true); placeWheel(insetZ, 1, true);
    placeWheel(-insetZ, -1, false); placeWheel(-insetZ, 1, false);
  }

  // underbody shadow puck
  const puck = new THREE.Mesh(
    new THREE.CircleGeometry(Math.max(W * 0.5, L * 0.42), 20),
    new THREE.MeshBasicMaterial({ color: '#000', transparent: true, opacity: 0.38, depthWrite: false })
  );
  puck.rotation.x = -Math.PI / 2;
  puck.position.y = 0.06;
  puck.scale.set(W / Math.max(W * 0.5, L * 0.42), L / Math.max(W * 0.5, L * 0.42), 1);
  g.add(puck);

  g.add(body);
  g.traverse((o) => {
    if (o instanceof THREE.Mesh) o.castShadow = true;
  });
  return { group: g, wheels, frontWheels, body, headlightMat: headMat, tailMat };
}

export function headlightBeam() {
  // a group of two spotlight quads for night driving — returns SpotLight
  const s = new THREE.SpotLight('#ffe9b0', 0, 60, 0.45, 0.5, 1.4);
  s.position.set(0, 1.1, 0);
  return s;
}
