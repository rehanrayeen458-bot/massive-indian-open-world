import * as THREE from 'three';
import { CITIES, type CityDef } from './data';
import { terrainHeight, coastZ } from './terrain';
import { distanceToRoads, type RoadSegment } from './roads';

export interface Interactable { x: number; z: number; radius: number; type: 'petrol' | 'garage'; name: string; used: boolean; sprite?: THREE.Sprite; }
export interface Collider { x: number; z: number; hw: number; hd: number; h: number; }

let _facadeMap: THREE.CanvasTexture | null = null;
let _glowMap: THREE.CanvasTexture | null = null;
let _facadeMat: THREE.MeshLambertMaterial | null = null;
export function getFacadeMaterial() {
  if (!_facadeMat) _facadeMat = new THREE.MeshLambertMaterial({ map: facadeTextureCanvas(), emissiveMap: glowTextureCanvas(), emissive: new THREE.Color('#ffb45e'), emissiveIntensity: 0.0 });
  return _facadeMat;
}
function facadeTextureCanvas(): THREE.CanvasTexture {
  if (_facadeMap) return _facadeMap;
  const cnv = document.createElement('canvas');
  cnv.width = 96; cnv.height = 128;
  const ctx = cnv.getContext('2d')!;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, 96, 128);
  for (let y = 0; y < 4; y++) {
    for (let x = 0; x < 3; x++) {
      const lit = Math.random() > 0.72;
      ctx.fillStyle = lit ? '#ffd98a' : '#33414f';
      ctx.fillRect(12 + x * 26, 12 + y * 30, 16, 20);
      ctx.strokeStyle = '#00000022';
      ctx.strokeRect(12 + x * 26, 12 + y * 30, 16, 20);
    }
  }
  ctx.fillStyle = '#00000018';
  ctx.fillRect(0, 0, 96, 8);
  _facadeMap = new THREE.CanvasTexture(cnv);
  _facadeMap.colorSpace = THREE.SRGBColorSpace;
  _facadeMap.anisotropy = 4;
  return _facadeMap;
}
function glowTextureCanvas(): THREE.CanvasTexture {
  if (_glowMap) return _glowMap;
  const cnv = document.createElement('canvas');
  cnv.width = 96; cnv.height = 128;
  const ctx = cnv.getContext('2d')!;
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, 96, 128);
  const rng = (x: number, y: number) => { const s = Math.sin(x * 91.7 + y * 47.3) * 43758.5453; return s - Math.floor(s); };
  for (let y = 0; y < 4; y++) {
    for (let x = 0; x < 3; x++) {
      if (rng(x, y) > 0.35) {
        ctx.fillStyle = '#ffca6e';
        ctx.fillRect(12 + x * 26, 12 + y * 30, 16, 20);
      }
    }
  }
  _glowMap = new THREE.CanvasTexture(cnv);
  _glowMap.colorSpace = THREE.SRGBColorSpace;
  return _glowMap;
}

const BUILDING_COLORS = ['#e8ddc9', '#d9c9a8', '#efe7d6', '#d4b98c', '#e3cdb0', '#cbb99a', '#f0e0c0', '#dfc9b4', '#e7d0b0', '#d6cfc0'];

// ─── monuments ────────────────────────────────────────────────────────────────
const mat = (color: string, rough = 0.85, metal = 0.0) =>
  new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });

export function createMonument(type: CityDef['monument'], name: string): THREE.Group {
  const g = new THREE.Group();
  const M = (geo: THREE.BufferGeometry, material: THREE.Material, x = 0, y = 0, z = 0) => {
    const m = new THREE.Mesh(geo, material);
    m.position.set(x, y, z);
    m.castShadow = true;
    g.add(m);
    return m;
  };

  const stone = mat('#d8c9ae');
  const darkStone = mat('#b9a583');
  const redEarth = mat('#c25b3a');
  const gold = mat('#f5c04a', 0.25, 0.9);
  const whiteMarble = mat('#f2ede2', 0.55, 0.08);

  switch (type) {
    case 'arch': { // India Gate
      const pil = new THREE.BoxGeometry(3.2, 26, 3.2);
      M(pil, stone, -6.4, 13, 0); M(pil, stone, 6.4, 13, 0);
      M(new THREE.BoxGeometry(18.4, 5.4, 4), stone, 0, 26, 0);
      M(new THREE.BoxGeometry(18.4, 1.6, 4.6), gold, 0, 29.4, 0);
      break;
    }
    case 'dome': { // Agra white marble / Amritsar gold
      const gold2 = name.toLowerCase().includes('amritsar');
      const bodyM = gold2 ? gold : whiteMarble;
      M(new THREE.BoxGeometry(26, 12, 26), whiteMarble, 0, 6, 0);
      M(new THREE.CylinderGeometry(8, 8, 9, 18), whiteMarble, 0, 15.5, 0);
      const dome = new THREE.Mesh(new THREE.SphereGeometry(8.6, 20, 14, 0, Math.PI * 2, 0, Math.PI / 2), bodyM);
      dome.position.set(0, 20, 0); dome.castShadow = true; g.add(dome);
      M(new THREE.SphereGeometry(1.4, 8, 8), gold, 0, 29.5, 0);
      break;
    }
    case 'minar': { // Qutub-style tower
      M(new THREE.CylinderGeometry(3.2, 4.4, 52, 12), darkStone, 0, 26, 0);
      M(new THREE.CylinderGeometry(2.6, 3.2, 10, 12), stone, 0, 57, 0);
      M(new THREE.ConeGeometry(2.6, 7, 12), gold, 0, 66, 0);
      break;
    }
    case 'gopuram': { // Karnataka tower
      M(new THREE.BoxGeometry(11, 15, 11), redEarth, 0, 7.5, 0);
      M(new THREE.BoxGeometry(8.4, 10, 8.4), redEarth, 0, 20, 0);
      M(new THREE.BoxGeometry(5.6, 7, 5.6), redEarth, 0, 28.5, 0);
      M(new THREE.ConeGeometry(4.2, 9, 4), gold, 0, 37.5, 0);
      break;
    }
    case 'fort': { // Jaipur / Jaisalmer fort
      M(new THREE.BoxGeometry(30, 16, 30), gold2(name), 0, 8, 0);
      M(new THREE.BoxGeometry(22, 6, 22), mat('#e6b75c'), 0, 19, 0);
      for (let i = -3; i <= 3; i++) {
        M(new THREE.BoxGeometry(2.4, 3, 2.4), mat('#f0cd7d'), i * 4.8, 26.2, 9.6);
        M(new THREE.BoxGeometry(2.4, 3, 2.4), mat('#f0cd7d'), i * 4.8, 26.2, -9.6);
      }
      M(new THREE.CylinderGeometry(2.6, 2.6, 7, 10), mat('#c96b3d'), 0, 30, 0);
      M(new THREE.SphereGeometry(3.2, 12, 10), gold, 0, 34, 0);
      break;
    }
    case 'ghats': { // Varanasi steps
      for (let i = 0; i < 4; i++) {
        M(new THREE.BoxGeometry(30 - i * 6, 2.4, 8), stone, 0, 8 - i * 2.4, i * 8 - 12);
      }
      // boat
      M(new THREE.BoxGeometry(2.6, 1.2, 9), mat('#6b4a26'), 6, 0.6, 22);
      break;
    }
    case 'mosque': { // Bhopal/Indore onion-domed mosque
      M(new THREE.BoxGeometry(20, 11, 20), whiteMarble, 0, 5.5, 0);
      const onion = new THREE.Mesh(new THREE.SphereGeometry(6, 16, 12), mat('#3e7ca8', 0.4));
      onion.scale.set(0.75, 1.25, 0.75);
      onion.position.set(0, 16, 0); onion.castShadow = true; g.add(onion);
      M(new THREE.CylinderGeometry(1.4, 1.8, 30, 8), whiteMarble, -13, 15, 0);
      M(new THREE.CylinderGeometry(1.4, 1.8, 30, 8), whiteMarble, 13, 15, 0);
      M(new THREE.SphereGeometry(1.7, 10, 8), gold, -13, 31, 0);
      M(new THREE.SphereGeometry(1.7, 10, 8), gold, 13, 31, 0);
      break;
    }
    case 'monastery': { // Leh
      M(new THREE.BoxGeometry(16, 5.5, 12), mat('#c9c2b4'), 0, 2.75, 0);
      M(new THREE.BoxGeometry(10, 4.5, 9), mat('#b7ada0'), 8, 2.25, 5);
      M(new THREE.ConeGeometry(4.2, 6.5, 8), gold, 0, 8.7, 0);
      for (let i = 0; i < 4; i++) {
        M(new THREE.CylinderGeometry(0.5, 0.5, 1.4, 6), mat('#c0392b'), -4 + i * 4, 6.6, 3);
      }
      break;
    }
    case 'palace': { // Jaipur/Lucknow/Kolkata
      M(new THREE.BoxGeometry(28, 10, 22), mat('#f2b8a0', 0.8), 0, 5, 0);
      M(new THREE.BoxGeometry(18, 7, 16), mat('#fbcbb0'), 0, 13.5, 0);
      for (let i = -2; i <= 2; i++) {
        M(new THREE.ConeGeometry(1.7, 4.4, 6), gold, i * 5.4, 19.4, 0);
      }
      M(new THREE.BoxGeometry(5, 8, 4), mat('#d98a6c'), 0, 4, 12);
      break;
    }
    case 'temple': { // shikhara
      M(new THREE.BoxGeometry(13, 9, 13), mat('#d8975a'), 0, 4.5, 0);
      M(new THREE.ConeGeometry(7.5, 13, 8), mat('#c2713a'), 0, 14, 0);
      M(new THREE.ConeGeometry(5, 8, 8), gold, 0, 22, 0);
      M(new THREE.SphereGeometry(1.6, 8, 8), gold, 0, 26.5, 0);
      break;
    }
    case 'observatory': {
      M(new THREE.CylinderGeometry(5.5, 6.5, 26, 12), mat('#e6e2da', 0.6), 0, 13, 0);
      M(new THREE.SphereGeometry(6.4, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2), mat('#5b6572', 0.35, 0.7), 0, 26.5, 0);
      M(new THREE.BoxGeometry(1.4, 1.2, 8), mat('#2c313a'), 0, 29, 2.5);
      break;
    }
    case 'obelisk': { // India Gate II / Mumbai
      M(new THREE.BoxGeometry(4.2, 34, 4.2), mat('#d8cdae', 0.5), 0, 17, 0);
      M(new THREE.ConeGeometry(3.2, 4.4, 4), gold, 0, 36.2, 0);
      M(new THREE.BoxGeometry(12, 2.4, 12), darkStone, 0, 1.2, 0);
      break;
    }
    case 'palm': {
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2, r = 8 + (i % 2) * 5;
        const trunk = M(new THREE.CylinderGeometry(0.9, 1.3, 9, 7), mat('#8a6b45'), Math.cos(a) * r, 4.5, Math.sin(a) * r);
        trunk.rotation.z = Math.cos(a) * 0.12;
        const crown = M(new THREE.SphereGeometry(3.4, 8, 6), mat('#3d7a3d'), Math.cos(a) * r * 1.06, 10.2, Math.sin(a) * r * 1.06);
        crown.scale.set(1.15, 0.5, 1.15);
      }
      break;
    }
    case 'mountain': {
      M(new THREE.ConeGeometry(16, 30, 6), mat('#cfd8de', 0.9), -10, 15, 0);
      M(new THREE.ConeGeometry(22, 42, 6), mat('#b8c4cd', 0.9), 6, 21, -6);
      M(new THREE.ConeGeometry(10, 18, 5), mat('#e3e9ee', 0.85), 18, 9, 8);
      break;
    }
    case 'lake': { // Srinagar / Udaipur pavilion
      M(new THREE.CylinderGeometry(7, 7.5, 2.6, 12), whiteMarble, 0, 1.3, 0);
      M(new THREE.ConeGeometry(7, 5.4, 12), mat('#c96b3d'), 0, 5.4, 0);
      break;
    }
  }
  return g;
}

function gold2(name: string) {
  return mat(name.toLowerCase().includes('jaisalmer') ? '#e9c568' : '#e0a55a');
}

// ─── signs ───────────────────────────────────────────────────────────────────
export function makeSignSprite(name: string, state: string) {
  const cnv = document.createElement('canvas');
  cnv.width = 512; cnv.height = 168;
  const ctx = cnv.getContext('2d')!;
  ctx.fillStyle = 'rgba(9,12,24,0.82)';
  roundRect(ctx, 4, 4, 504, 160, 26);
  ctx.fill();
  ctx.strokeStyle = '#f5b544';
  ctx.lineWidth = 5;
  roundRect(ctx, 10, 10, 492, 148, 22);
  ctx.stroke();
  ctx.fillStyle = '#ffe6a8';
  ctx.font = 'bold 52px "Bebas Neue", Impact, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(name.toUpperCase(), 256, 72);
  ctx.fillStyle = '#e8e2d2';
  ctx.font = '500 28px "Poppins", sans-serif';
  ctx.fillText(state, 256, 122);
  const tex = new THREE.CanvasTexture(cnv);
  tex.colorSpace = THREE.SRGBColorSpace;
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false });
  const s = new THREE.Sprite(mat);
  s.scale.set(64, 21, 1);
  return s;
}
function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

// ─── buildings ────────────────────────────────────────────────────────────────
export function createBuildings(city: CityDef, segments: RoadSegment[]) {
  const group = new THREE.Group();
  const colliders: Collider[] = [];
  const featured = city.featured;
  const count = featured ? 74 : 12;
  const R = featured ? city.radius * 0.62 : Math.max(city.radius * 0.45, 120);
  const mat = getFacadeMaterial();

  const boxGeo = new THREE.BoxGeometry(1, 1, 1);
  const roofGeo = new THREE.BoxGeometry(1, 0.32, 1);
  const inst = new THREE.InstancedMesh(boxGeo, mat, count * 2);
  const roofs = new THREE.InstancedMesh(roofGeo, new THREE.MeshLambertMaterial({ color: '#3a3a40' }), count * 2);
  inst.castShadow = true;
  inst.receiveShadow = true;
  roofs.castShadow = true;

  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const scale = new THREE.Vector3();
  const color = new THREE.Color();
  let placed = 0;
  const rng = (s: number) => { const v = Math.sin(s * 12.9898 + city.x * 0.001) * 43758.5453; return v - Math.floor(v); };

  let attempts = 0;
  while (placed < count && attempts < count * 7) {
    attempts++;
    const ang = rng(attempts * 3 + 1) * Math.PI * 2;
    const rr = Math.sqrt(rng(attempts * 3 + 2)) * R;
    const bx = city.x + Math.cos(ang) * rr;
    const bz = city.z + Math.sin(ang) * rr;
    if (Math.hypot(bx - city.x, bz - city.z) < (featured ? 90 : 60)) continue; // monument clearance
    if (terrainHeight(bx, bz) < 2) continue;
    if (distanceToRoads(bx, bz, segments) < 20) continue;
    const tall = featured ? (rng(attempts * 5 + 1) > 0.62 ? 2.4 + rng(attempts) * 2.2 : 0.55 + rng(attempts) * 0.7) : (0.4 + rng(attempts) * 0.45);
    const bw = (featured ? 13 : 10) + rng(attempts * 7) * 10;
    const bh = 16 * tall + 8;
    const bd = (featured ? 13 : 10) + rng(attempts * 9) * 10;
    const top = terrainHeight(bx, bz) - 2;
    q.setFromEuler(new THREE.Euler(0, rng(attempts * 11) * Math.PI * 0.5, 0));
    scale.set(bw, bh, bd);
    m.compose(new THREE.Vector3(bx, top + bh / 2, bz), q, scale);
    inst.setMatrixAt(placed, m);
    color.set(BUILDING_COLORS[Math.floor(rng(attempts * 13) * BUILDING_COLORS.length)]);
    inst.setColorAt(placed, color);
    // roof
    scale.set(bw * 0.94, 1, bd * 0.94);
    m.compose(new THREE.Vector3(bx, top + bh + 0.8, bz), q, scale);
    roofs.setMatrixAt(placed, m);
    colliders.push({ x: bx, z: bz, hw: bw / 2, hd: bd / 2, h: bh });
    placed++;
  }
  inst.count = placed;
  roofs.count = placed;
  inst.instanceMatrix.needsUpdate = true;
  roofs.instanceMatrix.needsUpdate = true;
  if (inst.instanceColor) inst.instanceColor.needsUpdate = true;
  group.add(inst, roofs);

  // monument
  const monument = createMonument(city.monument, city.name);
  monument.position.set(city.x, terrainHeight(city.x, city.z) - 1.5, city.z);
  group.add(monument);
  colliders.push({ x: city.x, z: city.z, hw: 26, hd: 26, h: 40 });

  // sign
  const sign = makeSignSprite(city.name, city.state);
  sign.position.set(city.x, terrainHeight(city.x, city.z) + 34, city.z + (featured ? 0 : 20));
  group.add(sign);

  // lake feature for lake/backwater types
  if (city.type === 'lake' || city.type === 'backwater') {
    const R = city.radius * (city.type === 'backwater' ? 0.9 : 0.75);
    const lakeMat = new THREE.MeshPhongMaterial({ color: '#14557a', emissive: '#07202f', specular: '#7ec3e8', shininess: 180 });
    const lake = new THREE.Mesh(new THREE.CircleGeometry(R, 48), lakeMat);
    lake.rotation.x = -Math.PI / 2;
    lake.position.set(city.x, terrainHeight(city.x, city.z) + 0.55, city.z);
    lake.scale.set(1.35, 1, 1);
    group.add(lake);
  }

  // beach for coastal types
  if (city.type === 'coast' || city.type === 'backwater' || city.id === 'goa') {
    const sand = new THREE.Mesh(
      new THREE.CircleGeometry(city.radius * 1.05, 40),
      new THREE.MeshStandardMaterial({ color: '#e6d391', roughness: 1 })
    );
    sand.rotation.x = -Math.PI / 2;
    sand.position.set(city.x, terrainHeight(city.x, city.z) + 0.35, city.z + 30);
    group.add(sand);
  }

  return { group, colliders, signSprite: sign };
}

// ─── trees & rocks ───────────────────────────────────────────────────────────
export function createVegetation(segments: RoadSegment[]) {
  const group = new THREE.Group();
  const count = 2400;
  const trunkGeo = new THREE.CylinderGeometry(0.32, 0.5, 2.6, 5);
  const canopyGeo = new THREE.ConeGeometry(2.7, 7.6, 7);
  const trunkMat = new THREE.MeshStandardMaterial({ color: '#5a4030', roughness: 1 });
  const canopyMat = new THREE.MeshStandardMaterial({ color: '#2e5b2e', roughness: 0.95 });
  const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, count);
  const canopies = new THREE.InstancedMesh(canopyGeo, canopyMat, count);
  trunks.castShadow = true;
  canopies.castShadow = true;

  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const col = new THREE.Color();
  let placed = 0;
  let attempts = 0;
  const range = WORLD_HALF();
  while (placed < count && attempts < count * 14) {
    attempts++;
    const x = (Math.random() * 2 - 1) * range * 0.96;
    const z = (Math.random() * 2 - 1) * range * 0.96;
    const h = terrainHeight(x, z);
    if (h < 4 || h > 560) continue;
    if (z > coastZ(x) - 250) continue;
    if (x < -8600) continue; // keep desert clear
    // cities clearance
    let inCity = false;
    for (const c of CITIES) {
      if (Math.hypot(x - c.x, z - c.z) < c.radius + 150) { inCity = true; break; }
    }
    if (inCity) continue;
    if (distanceToRoads(x, z, segments) < 22) continue;
    const sc = 0.7 + Math.random() * 0.85;
    const rot = Math.random() * Math.PI * 2;
    q.setFromEuler(new THREE.Euler(0, rot, 0));
    m.compose(
      new THREE.Vector3(x, h + 1.3 * sc, z),
      q,
      new THREE.Vector3(sc, sc, sc)
    );
    trunks.setMatrixAt(placed, m);
    m.compose(
      new THREE.Vector3(x, h + (2.6 + 3.8) * sc, z),
      q,
      new THREE.Vector3(sc * (0.85 + Math.random() * 0.4), sc * (0.8 + Math.random() * 0.5), sc * (0.85 + Math.random() * 0.4))
    );
    canopies.setMatrixAt(placed, m);
    col.setHSL(0.33 + Math.random() * 0.05, 0.42, 0.28 + Math.random() * 0.12);
    canopies.setColorAt(placed, col);
    placed++;
  }
  trunks.count = placed;
  canopies.count = placed;
  trunks.instanceMatrix.needsUpdate = true;
  canopies.instanceMatrix.needsUpdate = true;
  if (canopies.instanceColor) canopies.instanceColor.needsUpdate = true;
  group.add(trunks, canopies);

  // rocks
  const rockCount = 380;
  const rockGeo = new THREE.ConeGeometry(1.9, 2.6, 6);
  const rockMat = new THREE.MeshStandardMaterial({ color: '#8d8578', roughness: 1 });
  const rocks = new THREE.InstancedMesh(rockGeo, rockMat, rockCount);
  let rp = 0;
  attempts = 0;
  while (rp < rockCount && attempts < rockCount * 20) {
    attempts++;
    const x = (Math.random() * 2 - 1) * range * 0.92;
    const z = (Math.random() * 2 - 1) * range * 0.92;
    const h = terrainHeight(x, z);
    const inDesert = x < -8600;
    const inMountain = h > 240;
    if (!inDesert && !inMountain) continue;
    if (distanceToRoads(x, z, segments) < 18) continue;
    const sc = 0.5 + Math.random() * 1.6;
    q.setFromEuler(new THREE.Euler(0, Math.random() * Math.PI * 2, (Math.random() - 0.5) * 0.5));
    m.compose(new THREE.Vector3(x, h + 0.8 * sc, z), q, new THREE.Vector3(sc, sc, sc));
    rocks.setMatrixAt(rp, m);
    rp++;
  }
  rocks.count = rp;
  rocks.instanceMatrix.needsUpdate = true;
  group.add(rocks);
  return group;
}

function WORLD_HALF() { return 18000; }

// ─── interactable props (petrol pumps / garages) ─────────────────────────────
export function createInteractableProp(type: 'petrol' | 'garage') {
  const g = new THREE.Group();
  if (type === 'petrol') {
    // canopy
    const canopy = new THREE.Mesh(new THREE.BoxGeometry(10, 0.5, 7), new THREE.MeshStandardMaterial({ color: '#f7f5ee', roughness: 0.5 }));
    canopy.position.set(0, 4.6, 0);
    canopy.castShadow = true;
    g.add(canopy);
    const postMat = new THREE.MeshStandardMaterial({ color: '#8a8f98', roughness: 0.5, metalness: 0.6 });
    for (const [px, pz] of [[-4.4, -3], [4.4, -3], [-4.4, 3], [4.4, 3]] as const) {
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 4.4, 8), postMat);
      post.position.set(px, 2.2, pz);
      g.add(post);
    }
    // pump body
    const pump = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.0, 1.1), new THREE.MeshStandardMaterial({ color: '#d21f2e', roughness: 0.35, metalness: 0.5 }));
    pump.position.set(0, 1.0, 0);
    pump.castShadow = true;
    g.add(pump);
    const screen = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.5, 0.1), new THREE.MeshStandardMaterial({ color: '#111', emissive: '#3ec6ff', emissiveIntensity: 0.9 }));
    screen.position.set(0, 1.45, 0.58);
    g.add(screen);
    const sign = makeSignSprite('PETROL', 'INDIA');
    sign.scale.set(24, 7.6, 1);
    sign.position.set(0, 7.4, 0);
    g.add(sign);
  } else {
    // garage building
    const wallMat = new THREE.MeshStandardMaterial({ color: '#e0ded6', roughness: 0.8 });
    const wall = new THREE.Mesh(new THREE.BoxGeometry(18, 8, 12), wallMat);
    wall.position.set(0, 4, 0);
    wall.castShadow = true;
    g.add(wall);
    const roof = new THREE.Mesh(new THREE.BoxGeometry(19, 0.7, 13), new THREE.MeshStandardMaterial({ color: '#3d3d44' }));
    roof.position.set(0, 8.3, 0);
    g.add(roof);
    // garage bays (dark)
    for (const px of [-4.6, 0, 4.6]) {
      const bay = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 5.2), new THREE.MeshStandardMaterial({ color: '#0d0d10' }));
      bay.position.set(px, 2.7, 6.02);
      g.add(bay);
    }
    // logo
    const logo = makeSignSprite('GARAGE', 'SERVICE');
    logo.scale.set(22, 7, 1);
    logo.position.set(0, 10.4, 0);
    g.add(logo);
  }
  // ground slab
  const slab = new THREE.Mesh(new THREE.CircleGeometry(14, 24), new THREE.MeshStandardMaterial({ color: '#494d55', roughness: 0.95 }));
  slab.rotation.x = -Math.PI / 2;
  slab.position.y = 0.28;
  slab.receiveShadow = true;
  g.add(slab);
  return g;
}

export function createCityLayer(segments: RoadSegment[]) {
  const group = new THREE.Group();
  group.name = 'cities';
  const colliders: Collider[] = [];
  const zones: { city: CityDef; x: number; z: number; radius: number }[] = [];
  const signs: THREE.Sprite[] = [];

  for (const city of CITIES) {
    const built = createBuildings(city, segments);
    // position whole city group (monument, sign, building instances already world-positioned)
    group.add(built.group);
    built.group.position.set(0, 0, 0); // contents are world-space
    colliders.push(...built.colliders);
    zones.push({ city, x: city.x, z: city.z, radius: city.radius });
    signs.push(built.signSprite);
  }
  group.position.set(0, 0, 0);
  return { group, colliders, zones, signs, baseHeight: 0 };
}
