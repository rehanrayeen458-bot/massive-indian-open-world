import * as THREE from 'three';
import { ROADS } from './data';
import { terrainHeight } from './terrain';

export interface RoadSegment { ax: number; az: number; bx: number; bz: number; }

function roadTexture() {
  const cnv = document.createElement('canvas');
  cnv.width = 128; cnv.height = 128;
  const ctx = cnv.getContext('2d')!;
  // asphalt
  ctx.fillStyle = '#2c2f36';
  ctx.fillRect(0, 0, 128, 128);
  // subtle noise
  for (let i = 0; i < 520; i++) {
    const v = 40 + Math.random() * 22;
    ctx.fillStyle = `rgba(${v},${v},${v + 6},0.5)`;
    ctx.fillRect(Math.random() * 128, Math.random() * 128, 2, 2);
  }
  // edge lines (solid)
  ctx.fillStyle = '#e8e4d8';
  ctx.fillRect(4, 0, 5, 128);
  ctx.fillRect(119, 0, 5, 128);
  // center dashes
  ctx.fillStyle = '#f5d54a';
  ctx.fillRect(61, 6, 6, 46);
  ctx.fillRect(61, 70, 6, 46);
  const tex = new THREE.CanvasTexture(cnv);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 8;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createRoads() {
  const group = new THREE.Group();
  group.name = 'roads';
  const tex = roadTexture();
  const material = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.95, metalness: 0.0, side: THREE.DoubleSide });
  const segments: RoadSegment[] = [];

  for (const road of ROADS) {
    const pts = road.pts;
    const cum: number[] = [0];
    for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
    const total = cum[cum.length - 1];
    const step = 22;
    const positions: number[] = [];
    const uvs: number[] = [];
    const indices: number[] = [];
    const width = 13;
    let row = 0;
    const nRows = Math.floor(total / step) + 1;
    let prevCx = 0, prevCz = 0, first = true;
    for (let s = 0; s <= total; s += step, row++) {
      let i = 0;
      while (i < cum.length - 1 && cum[i + 1] < s) i++;
      const t = (s - cum[i]) / Math.max(1e-6, cum[i + 1] - cum[i]);
      const ax = pts[i][0], az = pts[i][1];
      const bx = pts[i + 1][0], bz = pts[i + 1][1];
      const dx = bx - ax, dz = bz - az;
      const len = Math.hypot(dx, dz) || 1;
      const nx = -dz / len, nz = dx / len;
      const cx = ax + dx * t, cz = az + dz * t;
      const yL = terrainHeight(cx + nx * width * 0.5, cz + nz * width * 0.5);
      const yC = terrainHeight(cx, cz);
      const yR = terrainHeight(cx - nx * width * 0.5, cz - nz * width * 0.5);
      const road = Math.max(yL, yC, yR);
      positions.push(cx + nx * width * 0.5, road + 0.65, cz + nz * width * 0.5);
      positions.push(cx, road + 0.65, cz);
      positions.push(cx - nx * width * 0.5, road + 0.65, cz - nz * width * 0.5);
      uvs.push(0, s / 24, 0.5, s / 24, 1, s / 24);
      if (!first && row % 2 === 0) segments.push({ ax: prevCx, az: prevCz, bx: cx, bz: cz });
      prevCx = cx; prevCz = cz; first = false;
    }
    for (let r = 0; r < nRows - 1; r++) {
      const a = r * 3, b = r * 3 + 3;
      // left-center
      indices.push(a, a + 1, b, b, a + 1, b + 1);
      // center-right
      indices.push(a + 1, a + 2, b + 1, b + 1, a + 2, b + 2);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    const mat = material.clone();
    mat.map = tex.clone();
    mat.map.needsUpdate = true;
    mat.map.repeat.set(1, 1);
    mat.map.wrapT = THREE.RepeatWrapping;
    mat.map.wrapS = THREE.RepeatWrapping;
    const mesh = new THREE.Mesh(geo, mat);
    mesh.receiveShadow = true;
    mesh.name = `road-${road.id}`;
    group.add(mesh);
  }
  return { group, segments };
}

// distance from point to nearest road sample segment (for off-road detection)
export function distanceToRoads(x: number, z: number, segments: RoadSegment[]) {
  let best = Infinity;
  for (let i = 0; i < segments.length; i++) {
    const s = segments[i];
    const dx = s.bx - s.ax, dz = s.bz - s.az;
    const l2 = dx * dx + dz * dz;
    let t = l2 > 0 ? ((x - s.ax) * dx + (z - s.az) * dz) / l2 : 0;
    t = Math.max(0, Math.min(1, t));
    const px = s.ax + dx * t, pz = s.az + dz * t;
    const d = Math.hypot(x - px, z - pz);
    if (d < best) best = d;
  }
  return best;
}
