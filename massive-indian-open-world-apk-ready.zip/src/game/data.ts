// ─── WORLD DATA ───────────────────────────────────────────────────────────────
export const WORLD = {
  size: 36000,
  half: 18000,
  seaLevel: 0,
};

export interface CityDef {
  id: string;
  name: string;
  state: string;
  x: number;
  z: number;
  featured: boolean;   // big city: buildings, sign, traffic
  radius: number;      // discovery radius
  monument:
    | 'arch' | 'dome' | 'minar' | 'gopuram' | 'fort' | 'ghats' | 'mosque'
    | 'monastery' | 'palace' | 'temple' | 'observatory' | 'obelisk' | 'palm' | 'mountain' | 'lake';
  flavor: string;
  type: 'city' | 'town' | 'hill' | 'lake' | 'desert' | 'coast' | 'backwater' | 'plateau' | 'island';
}

// ─── ALL 28 STATES + 8 UNION TERRITORIES ──────────────────────────────────────
export const CITIES: CityDef[] = [
  // ── Uttar Pradesh (3)
  { id: 'lucknow', name: 'Lucknow', state: 'Uttar Pradesh', x: -1600, z: -3200, featured: true, radius: 300, monument: 'palace', flavor: 'The City of Nawabs', type: 'city' },
  { id: 'agra', name: 'Agra', state: 'Uttar Pradesh', x: -2700, z: -2750, featured: true, radius: 230, monument: 'dome', flavor: 'City of the Taj', type: 'city' },
  { id: 'varanasi', name: 'Varanasi', state: 'Uttar Pradesh', x: -800, z: -2650, featured: true, radius: 240, monument: 'ghats', flavor: 'City of Light', type: 'city' },
  // ── Delhi UT
  { id: 'delhi', name: 'Delhi', state: 'National Capital', x: -3600, z: -3600, featured: true, radius: 320, monument: 'arch', flavor: 'India Gate & Red Fort', type: 'city' },
  // ── Delhi neighbor — Haryana
  { id: 'gurugram', name: 'Gurugram', state: 'Haryana', x: -4300, z: -3350, featured: true, radius: 260, monument: 'observatory', flavor: 'The Millennium City', type: 'city' },
  // ── Punjab
  { id: 'amritsar', name: 'Amritsar', state: 'Punjab', x: -6300, z: -5100, featured: true, radius: 260, monument: 'dome', flavor: 'City of the Golden Temple', type: 'city' },
  // ── Chandigarh UT
  { id: 'chandigarh', name: 'Chandigarh', state: 'Chandigarh UT', x: -5450, z: -5450, featured: true, radius: 220, monument: 'obelisk', flavor: 'The City Beautiful', type: 'city' },
  // ── Rajasthan (3)
  { id: 'jaipur', name: 'Jaipur', state: 'Rajasthan', x: -6800, z: -1600, featured: true, radius: 300, monument: 'fort', flavor: 'The Pink City', type: 'city' },
  { id: 'jaisalmer', name: 'Jaisalmer', state: 'Rajasthan', x: -10600, z: -4800, featured: true, radius: 220, monument: 'fort', flavor: 'The Golden City', type: 'desert' },
  { id: 'udaipur', name: 'Udaipur', state: 'Rajasthan', x: -6200, z: 4200, featured: true, radius: 240, monument: 'lake', flavor: 'The City of Lakes', type: 'lake' },
  // ── Uttarakhand
  { id: 'rishikesh', name: 'Rishikesh', state: 'Uttarakhand', x: -2400, z: -6300, featured: true, radius: 190, monument: 'temple', flavor: 'Yoga Capital of the World', type: 'hill' },
  // ── Himachal Pradesh (2)
  { id: 'shimla', name: 'Shimla', state: 'Himachal Pradesh', x: -2100, z: -7500, featured: true, radius: 240, monument: 'fort', flavor: 'The Queen of Hills', type: 'hill' },
  { id: 'manali', name: 'Manali', state: 'Himachal Pradesh', x: -2900, z: -8300, featured: true, radius: 200, monument: 'mountain', flavor: 'Ladakh runway gateway', type: 'hill' },
  // ── J&K UT
  { id: 'srinagar', name: 'Srinagar', state: 'Jammu & Kashmir', x: -6600, z: -9800, featured: true, radius: 280, monument: 'lake', flavor: 'Valley of Pleasure', type: 'lake' },
  // ── Leh (Ladakh UT)
  { id: 'leh', name: 'Leh', state: 'Ladakh UT', x: -2550, z: -10800, featured: true, radius: 240, monument: 'monastery', flavor: 'Home of Tranquility', type: 'plateau' },
  // ── Haryana → Gurugram done; MP (4)
  { id: 'indore', name: 'Indore', state: 'Madhya Pradesh', x: -1800, z: 900, featured: true, radius: 280, monument: 'mosque', flavor: 'City of Lakes — Indore', type: 'city' },
  { id: 'bhopal', name: 'Bhopal', state: 'Madhya Pradesh', x: -100, z: 1900, featured: true, radius: 280, monument: 'mosque', flavor: 'Mini Switzerland of India', type: 'city' },
  { id: 'gwalior', name: 'Gwalior', state: 'Madhya Pradesh', x: -2700, z: -700, featured: false, radius: 150, monument: 'fort', flavor: 'Historic Fort City', type: 'town' },
  { id: 'ujjain', name: 'Ujjain', state: 'Madhya Pradesh', x: -3600, z: 1600, featured: false, radius: 150, monument: 'minar', flavor: 'Gateway to Kumbh', type: 'town' },
  { id: 'jabalpur', name: 'Jabalpur', state: 'Madhya Pradesh', x: 1100, z: 1600, featured: false, radius: 150, monument: 'fort', flavor: 'The Natural Harbour', type: 'town' },
  { id: 'guna', name: 'Guna', state: 'Madhya Pradesh', x: -3300, z: 600, featured: false, radius: 140, monument: 'palace', flavor: 'Luxury City of Bhopal', type: 'town' },
  // ── Bihar
  { id: 'patna', name: 'Patna', state: 'Bihar', x: 500, z: -2650, featured: true, radius: 260, monument: 'obelisk', flavor: 'Heart of Bihar', type: 'city' },
  // ── Jharkhand
  { id: 'ranchi', name: 'Ranchi', state: 'Jharkhand', x: 3600, z: 1000, featured: false, radius: 160, monument: 'temple', flavor: 'Hill Capital', type: 'hill' },
  // ── Odisha
  { id: 'bhubaneswar', name: 'Bhubaneswar', state: 'Odisha', x: 5200, z: 2600, featured: true, radius: 260, monument: 'gopuram', flavor: 'The City of Temples', type: 'city' },
  // ── West Bengal
  { id: 'kolkata', name: 'Kolkata', state: 'West Bengal', x: 6800, z: -1400, featured: true, radius: 330, monument: 'palace', flavor: 'City of Joy', type: 'city' },
  // ── Assam
  { id: 'guwahati', name: 'Guwahati', state: 'Assam', x: 4800, z: -6500, featured: true, radius: 240, monument: 'temple', flavor: 'Gateway to Assam', type: 'city' },
  // ── Tripura
  { id: 'agartala', name: 'Agartala', state: 'Tripura', x: 4700, z: -2700, featured: false, radius: 150, monument: 'temple', flavor: 'The Jewel of Northeast', type: 'hill' },
  // ── Sikkim
  { id: 'gangtok', name: 'Gangtok', state: 'Sikkim', x: 4400, z: -5500, featured: false, radius: 160, monument: 'fort', flavor: 'Jewel of the East', type: 'hill' },
  // ── Manipur
  { id: 'imphal', name: 'Imphal', state: 'Manipur', x: 5200, z: -4700, featured: false, radius: 160, monument: 'temple', flavor: 'Valley of Gems', type: 'hill' },
  // ── Meghalaya
  { id: 'shillong', name: 'Shillong', state: 'Meghalaya', x: 4000, z: -3800, featured: false, radius: 150, monument: 'fort', flavor: 'The Switzerland of India', type: 'hill' },
  // ── Mizoram
  { id: 'aizawl', name: 'Aizawl', state: 'Mizoram', x: 4800, z: -3400, featured: false, radius: 150, monument: 'fort', flavor: 'City of Hills', type: 'hill' },
  // ── Nagaland
  { id: 'kohima', name: 'Kohima', state: 'Nagaland', x: 5600, z: -5200, featured: false, radius: 150, monument: 'fort', flavor: 'The Orange City', type: 'hill' },
  // ── Arunachal
  { id: 'itanagar', name: 'Itanagar', state: 'Arunachal Pradesh', x: 6400, z: -7600, featured: false, radius: 150, monument: 'temple', flavor: 'Capital of Arunachal', type: 'hill' },
  // ── Chhattisgarh
  { id: 'raipur', name: 'Raipur', state: 'Chhattisgarh', x: 300, z: 3100, featured: false, radius: 160, monument: 'temple', flavor: 'Crossroads of the East', type: 'town' },
  // ── Maharashtra (2)
  { id: 'mumbai', name: 'Mumbai', state: 'Maharashtra', x: -3400, z: 7800, featured: true, radius: 340, monument: 'obelisk', flavor: 'The Bollywood Capital', type: 'city' },
  { id: 'pune', name: 'Pune', state: 'Maharashtra', x: -4300, z: 5700, featured: true, radius: 280, monument: 'observatory', flavor: 'The Oxford of India', type: 'city' },
  // ── Goa
  { id: 'goa', name: 'Goa', state: 'Goa', x: -5200, z: 7300, featured: true, radius: 220, monument: 'palm', flavor: 'The Republic of Wine', type: 'coast' },
  // ── Karnataka
  { id: 'bengaluru', name: 'Bengaluru', state: 'Karnataka', x: -1600, z: 6900, featured: true, radius: 300, monument: 'dome', flavor: 'The Silicon City', type: 'city' },
  // ── Kerala (2)
  { id: 'kochi', name: 'Kochi', state: 'Kerala', x: -4700, z: 9100, featured: true, radius: 220, monument: 'palace', flavor: 'The Queen of the Arabian Sea', type: 'coast' },
  { id: 'backwaters', name: 'Alleppey Backwaters', state: 'Kerala', x: -4100, z: 9600, featured: true, radius: 230, monument: 'palm', flavor: 'God’s Own Country', type: 'backwater' },
  // ── Gujarat (2)
  { id: 'ahmedabad', name: 'Ahmedabad', state: 'Gujarat', x: -6200, z: 2400, featured: true, radius: 300, monument: 'mosque', flavor: 'The Walled City', type: 'city' },
  { id: 'kutch', name: 'Kutch', state: 'Gujarat', x: -10600, z: 1500, featured: true, radius: 200, monument: 'palm', flavor: 'The Thar Desert', type: 'desert' },
  // ── Tamil Nadu
  { id: 'chennai', name: 'Chennai', state: 'Tamil Nadu', x: 1600, z: 9200, featured: true, radius: 300, monument: 'gopuram', flavor: 'City of Palaces', type: 'coast' },
  // ── Telangana
  { id: 'hyderabad', name: 'Hyderabad', state: 'Telangana', x: -300, z: 4500, featured: true, radius: 300, monument: 'mosque', flavor: 'The City of Charminar', type: 'city' },
  // ── Andhra Pradesh
  { id: 'vijayawada', name: 'Vijayawada', state: 'Andhra Pradesh', x: 1900, z: 5600, featured: false, radius: 160, monument: 'gopuram', flavor: 'City of Temples', type: 'city' },
  // ── Puducherry UT
  { id: 'puducherry', name: 'Puducherry', state: 'Puducherry UT', x: 2500, z: 8600, featured: false, radius: 150, monument: 'obelisk', flavor: 'The French Colony', type: 'coast' },
  // ── Dadra & Nagar Haveli + Daman & Diu UT
  { id: 'daman', name: 'Daman', state: 'Daman & Diu UT', x: -6000, z: 5800, featured: false, radius: 150, monument: 'palm', flavor: 'Island Colony', type: 'coast' },
  // ── Andaman & Nicobar UT
  { id: 'portblair', name: 'Port Blair', state: 'Andaman & Nicobar UT', x: 5200, z: 11800, featured: false, radius: 160, monument: 'palm', flavor: 'Islands of Andaman', type: 'island' },
  // ── Lakshadweep UT
  { id: 'kavaratti', name: 'Kavaratti', state: 'Lakshadweep UT', x: -5200, z: 11400, featured: false, radius: 160, monument: 'palm', flavor: 'Islands of Lakshadweep', type: 'island' },
  // ── Gulmarg town (J&K)
  { id: 'gulmarg', name: 'Gulmarg', state: 'Jammu & Kashmir', x: -6100, z: -10600, featured: false, radius: 160, monument: 'mountain', flavor: 'The Meadow of Giants', type: 'hill' },
] as CityDef[];

export const TOTAL_EXPLORES = CITIES.length;

// ─── ROADS (polylines through cities/roads) ───────────────────────────────────
export const ROADS: { id: string; name: string; pts: [number, number][] }[] = [
  { id: 'r1', name: 'NH27 Desert Highway', pts: [[-10600,-4800],[-9200,-4200],[-8200,-3300],[-6800,-1600],[-5600,-2500],[-3600,-3600],[-2700,-3300],[-1600,-3200],[-800,-2650],[500,-2650],[3400,-2300],[6800,-1400]] },
  { id: 'r2', name: 'NH48 Gujarat Highway', pts: [[-6800,-1600],[-6600,0],[-6200,2400],[-5800,4000],[-6000,5600]] },
  { id: 'r2b', name: 'Kutch Highway', pts: [[-6200,2400],[-7800,2600],[-9200,2200],[-10600,1500]] },
  { id: 'r3', name: 'NH44 Golden Highway', pts: [[-3600,-3600],[-4600,-4300],[-5600,-5100],[-6300,-5100],[-6600,-6600],[-6700,-8300],[-6600,-9800]] },
  { id: 'r4', name: 'NH3 Himalayas Highway', pts: [[-3600,-3600],[-3000,-4800],[-2300,-5800],[-2100,-7500],[-2500,-8300],[-2700,-9500],[-2550,-10800]] },
  { id: 'r5', name: 'Agra Expressway', pts: [[-3600,-3600],[-2700,-2750],[-800,-2650]] },
  { id: 'r6', name: 'Mumbai–Hyderabad Highway', pts: [[-3400,7800],[-3800,6600],[-4300,5700],[-3400,3500],[-1800,900],[-100,1900],[-300,4500],[1900,5600],[1600,9200]] },
  { id: 'r7', name: 'Konkan Coastal Road', pts: [[-3400,7800],[-4500,7650],[-5200,7300],[-4700,9100],[-4100,9600]] },
  { id: 'r8', name: 'Bengaluru Coast Road', pts: [[-1600,6900],[-400,8000],[1600,9200],[2500,8600]] },
  { id: 'r9', name: 'Chhattisgarh Highway', pts: [[-100,1900],[700,1800],[1100,1600],[2500,1400],[3600,1000],[4200,-600],[4400,-2000],[4800,-6500]] },
  { id: 'r10', name: 'East Coast NH16', pts: [[-800,-2650],[1400,-1700],[2600,600],[5200,2600]] },
  { id: 'r11', name: 'NE Expressway', pts: [[6800,-1400],[6000,-1800],[4700,-2700],[5200,-4700],[5600,-5200],[6400,-7600]] },
  { id: 'r12', name: 'Udaipur Highway', pts: [[-6800,-1600],[-7000,1200],[-6200,4200]] },
  { id: 'r13', name: 'Udagam Expressway', pts: [[-6200,4200],[-4500,4300],[-2000,4100],[-100,4500]] },
  { id: 'r14', name: 'Gulf Highway', pts: [[-300,4500],[650,5100],[1900,5600],[1800,7200],[1600,9200]] },
  { id: 'r15', name: 'Varanasi–Kolkata Highway', pts: [[-800,-2650],[1800,-2300],[6800,-1400]] },
  { id: 'r16', name: 'Indore–Ujjain Highway', pts: [[-1800,900],[-2600,1200],[-3600,1600]] },
  { id: 'r17', name: 'Howrah Expressway', pts: [[6800,-1400],[6200,-800],[5200,100],[5200,2600]] },
];

// ─── VEHICLE CATALOG ──────────────────────────────────────────────────────────
export type VehicleKey =
  | 'bmw' | 'mercedes' | 'audi' | 'porsche' | 'lambo' | 'bugatti'
  | 'thar' | 'scorpio' | 'fortuner' | 'innova' | 'swift' | 'creta'
  | 'enfield' | 'truck' | 'bus';

export interface VehicleSpec {
  key: VehicleKey;
  name: string;
  class: 'luxury' | 'suv' | 'city' | 'bike' | 'heavy' | 'bus';
  topSpeed: number; // km/h
  accel: number;    // km/h per second
  width: number;
  length: number;
  mass: number;   // relative
  defaultColor: string;
  desc: string;
}

export const VEHICLES: VehicleSpec[] = [
  { key: 'swift', name: 'Swift Sport', class: 'city', topSpeed: 205, accel: 14, width: 1.7, length: 3.9, mass: 1.0, defaultColor: '#c0c8cc', desc: 'City runabout' },
  { key: 'bmw', name: 'BMW 5-Series', class: 'luxury', topSpeed: 245, accel: 16, width: 1.9, length: 4.9, mass: 1.1, defaultColor: '#141a22', desc: 'Luxury sedan' },
  { key: 'mercedes', name: 'Mercedes E-Class', class: 'luxury', topSpeed: 255, accel: 16, width: 1.9, length: 4.9, mass: 1.1, defaultColor: '#b9bec6', desc: 'Executive sedan' },
  { key: 'audi', name: 'Audi RS', class: 'luxury', topSpeed: 260, accel: 17, width: 1.9, length: 4.9, mass: 1.1, defaultColor: '#2b3442', desc: 'Sport sedan' },
  { key: 'porsche', name: 'Porsche Carrera', class: 'luxury', topSpeed: 295, accel: 19, width: 1.9, length: 4.6, mass: 1.0, defaultColor: '#e8b30e', desc: 'Super sedan' },
  { key: 'lambo', name: 'Lamborghini Huracán', class: 'luxury', topSpeed: 335, accel: 21, width: 2.0, length: 4.6, mass: 0.9, defaultColor: '#e5c71b', desc: 'Supercar' },
  { key: 'bugatti', name: 'Bugatti Centodieci', class: 'luxury', topSpeed: 410, accel: 25, width: 2.0, length: 4.7, mass: 0.9, defaultColor: '#b00f1e', desc: 'Hypercar' },
  { key: 'creta', name: 'Creta S', class: 'suv', topSpeed: 205, accel: 15, width: 1.85, length: 4.4, mass: 1.2, defaultColor: '#35506b', desc: 'Compact SUV' },
  { key: 'thar', name: 'Mahindra Thar', class: 'suv', topSpeed: 180, accel: 13, width: 2.05, length: 4.3, mass: 1.3, defaultColor: '#7c4a2d', desc: 'Off-road icon' },
  { key: 'scorpio', name: 'Scorpio N', class: 'suv', topSpeed: 185, accel: 13, width: 2.05, length: 4.8, mass: 1.5, defaultColor: '#3d3d3d', desc: 'Full-size SUV' },
  { key: 'fortuner', name: 'Fortuner', class: 'suv', topSpeed: 200, accel: 14, width: 1.95, length: 4.9, mass: 1.45, defaultColor: '#274435', desc: 'Off-road SUV' },
  { key: 'innova', name: 'Innova Crysta', class: 'suv', topSpeed: 190, accel: 14, width: 1.95, length: 5.0, mass: 1.4, defaultColor: '#e8e9eb', desc: 'MPV lounge' },
  { key: 'enfield', name: 'Royal Enfield Himalayan', class: 'bike', topSpeed: 145, accel: 15, width: 0.9, length: 2.3, mass: 0.35, defaultColor: '#1f5fa8', desc: 'Adventure bike' },
  { key: 'truck', name: 'Ashok Leyland Truck', class: 'heavy', topSpeed: 105, accel: 9, width: 2.5, length: 9.5, mass: 2.6, defaultColor: '#c94f1e', desc: 'Heavy hauler' },
  { key: 'bus', name: 'Volvo Bus', class: 'bus', topSpeed: 135, accel: 10, width: 2.5, length: 11.5, mass: 2.4, defaultColor: '#f2ede2', desc: 'Tour bus' },
];

export const VEHICLE_COLORS = [
  '#141a22', '#e8e9eb', '#e5c71b', '#b00f1e', '#35506b', '#1f5fa8',
  '#c94f1e', '#274435', '#e8b30e', '#c0c8cc', '#7c4a2d', '#3d3d3d',
];

// ─── SPAWN ────────────────────────────────────────────────────────────────────
export const SPAWN = { x: -4100, z: -3500, heading: Math.PI / 2 }; // near Delhi, facing east on NH27

export const SHOP_NAMES = [
  'Petrol Pump', 'Petrol Pump', 'Petrol Pump',
];

// ─── Interaction points (petrol + garage) around featured cities ─────────────
export function buildInteractables() {
  const spots: { x: number; z: number; type: 'petrol' | 'garage'; name: string }[] = [];
  const featured = CITIES.filter((c) => c.featured);
  featured.forEach((c) => {
    spots.push({ x: c.x + 150, z: c.z - 110, type: 'petrol', name: `${c.name} Petrol Pump` });
    spots.push({ x: c.x - 170, z: c.z + 130, type: 'garage', name: `${c.name} Garage` });
  });
  return spots;
}
