import * as THREE from 'three';
import { WORLD } from './data';

// ─── deterministic noise ──────────────────────────────────────────────────────
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
export const smooth = (a: number, b: number, v: number) => {
  const t = clamp01((v - a) / (b - a));
  return t * t * (3 - 2 * t);
};

function hash(x: number, z: number) {
  const s = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
  return s - Math.floor(s);
}

export function vnoise(x: number, z: number) {
  const xi = Math.floor(x), zi = Math.floor(z);
  const xf = x - xi, zf = z - zi;
  const u = xf * xf * (3 - 2 * xf), v = zf * zf * (3 - 2 * zf);
  const a = hash(xi, zi), b = hash(xi + 1, zi), c = hash(xi, zi + 1), d = hash(xi + 1, zi + 1);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}

export function fbm(x: number, z: number, oct = 4) {
  let sum = 0, amp = 0.5, f = 1, norm = 0;
  for (let i = 0; i < oct; i++) {
    sum += vnoise(x * f, z * f) * amp;
    norm += amp; amp *= 0.5; f *= 2.03;
  }
  return sum / norm;
}

// ─── coastline: SW → E diagonal ───────────────────────────────────────────────
export function coastZ(x: number) {
  if (x > 3000) return 9000 + (x - 3000) * 0.12;
  return 7700 + (x + 10600) * 0.3;
}

function islandBump(x: number, z: number, cx: number, cz: number, r: number, h: number) {
  const d = Math.hypot(x - cx, z - cz);
  const t = clamp01(1 - d / r);
  return t * t * h;
}

export function terrainHeight(x: number, z: number) {
  // base plains
  let h = 42 + fbm(x * 0.00022, z * 0.00022, 4) * 95;

  // north mountain range (Himachal / Himalaya region)
  const north = smooth(-6200, -9500, z);
  h += north * (fbm(x * 0.0016 + 40, z * 0.0016, 4) * 620 + 130);

  // Himalaya spine
  const him = smooth(-9500, -12500, z);
  h += him * (fbm(x * 0.0007 + 9, z * 0.0007, 5) * 560 + 170);

  // Rajasthan plateau (west)
  const raj = smooth(-4400, -6800, x) * (1 - smooth(3200, 5600, z));
  h += raj * (fbm(x * 0.0011 + 200, z * 0.0011, 3) * 75 + 115);

  // Western Ghats — narrow ridge WEST of the coastal strip
  const gat = smooth(-8200, -7000, x) * (1 - smooth(-5300, -4300, x)) * smooth(1500, 3200, z) * (1 - smooth(10200, 12000, z));
  h += gat * (fbm(x * 0.0016 + 777, z * 0.0016, 4) * 190 + 90);

  // Northeast hills
  const neX = smooth(3400, 5000, x);
  const neZ = 1 - smooth(-900, 700, z);
  h += neX * neZ * (fbm(x * 0.0015 + 500, z * 0.0015, 4) * 540 + 230);

  // central plateau (Madhya Pradesh forest) — gentle
  const central = smooth(-3800, -1200, x) * (1 - smooth(-1200, -600, x)) * smooth(-600, 600, z) * (1 - smooth(3400, 4600, z));
  h += central * (fbm(x * 0.0013 + 700, z * 0.0013, 3) * 60 + 32);

  // Kerala strip (SW, near coast) — rolling
  const ker = smooth(-6200, -5100, x) * (1 - smooth(2200, 3000, x)) * smooth(5200, 6800, z);
  h += ker * (fbm(x * 0.0016 + 900, z * 0.0016, 3) * 130 + 55);

  // coastline — drop to sea with beach
  const coast = coastZ(x);
  if (z > coast) {
    const islands = Math.max(
      islandBump(x, z, 5200, 11800, 260, 8),
      islandBump(x, z, -5200, 11500, 220, 7),
      islandBump(x, z, -800, 11100, 130, 5) // tiny Andaman speck
    );
    return Math.max(islands, -9 - fbm(x * 0.0008, z * 0.0008, 2) * 3);
  }
  const beach = smooth(coast - 430, coast, z);
  h = h * (1 - beach) + 5.5 * beach;

  return h;
}

// ─── colors ───────────────────────────────────────────────────────────────────
const cGrass = new THREE.Color('#5e8446');
const cWheat = new THREE.Color('#c2ac62');
const cSand = new THREE.Color('#d9b476');
const cRock = new THREE.Color('#7d7466');
const cSnow = new THREE.Color('#eef2f6');
const cForest = new THREE.Color('#3d6238');
const cSandDark = new THREE.Color('#c19a5a');
const cBeach = new THREE.Color('#e0cd90');

export function terrainColor(x: number, z: number, h: number): THREE.Color {
  const noise = fbm(x * 0.001 + 1200, z * 0.001, 3);
  const out = new THREE.Color();
  const coast = coastZ(x);

  // Rajasthan desert & Kutch
  const desert = smooth(-8600, -10200, x) * (1 - smooth(-1200, 200, z));
  const ghats = smooth(-6800, -5400, x) * (1 - smooth(3600, 4300, x));
  const north = smooth(-6200, -9500, z);
  const ne = smooth(3400, 5000, x) * (1 - smooth(-900, 700, z));

  if (desert > 0.18 && h < 240) {
    out.copy(cSand).lerp(cSandDark, noise * 0.6);
    out.lerp(cBeach, smooth(coast - 500, coast, z));
    return out;
  }
  if (h > 520) { // mountains
    out.copy(cRock).lerp(cSnow, smooth(640, 880, h));
    if (north > 0.4) out.lerp(cForest, 0.35 * (1 - smooth(0.5, 1, h / 900)));
    return out;
  }
  if (h > 300) {
    out.copy(cRock).lerp(cForest, 0.55);
    if (ne > 0.3 || ghats > 0.3 || north > 0.4) out.copy(cForest).lerp(cRock, 0.35);
    return out;
  }
  // rolling green / wheat plains
  const wheatMix = fbm(x * 0.0009 + 50, z * 0.0009 + 50, 3);
  out.copy(cGrass).lerp(cWheat, wheatMix * 0.85);
  if (ghats > 0.3) out.copy(cForest).lerp(cGrass, 0.35);
  if (ne > 0.3) out.copy(cForest).lerp(cGrass, 0.3);
  // beach sandy rim
  const beachMix = smooth(coast - 480, coast - 40, z);
  out.lerp(cBeach, beachMix);
  return out;
}

// ─── terrain mesh ─────────────────────────────────────────────────────────────
export function createTerrain() {
  const SEG = WORLD.size >= 36000 ? 380 : 260;
  const geo = new THREE.PlaneGeometry(WORLD.size, WORLD.size, SEG, SEG);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count * 3);
  const col = new THREE.Color();
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i);
    const h = terrainHeight(x, z);
    pos.setY(i, h);
    col.copy(terrainColor(x, z, h));
    // slight tint variation for liveliness
    const v = 0.92 + vnoise(x * 0.02, z * 0.02) * 0.16;
    colors[i * 3] = col.r * v;
    colors[i * 3 + 1] = col.g * v;
    colors[i * 3 + 2] = col.b * v;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geo.computeVertexNormals();
  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1.0, metalness: 0.0 });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.receiveShadow = true;
  mesh.name = 'terrain';
  return mesh;
}

export function createSea() {
  const geo = new THREE.PlaneGeometry(WORLD.size * 2.4, WORLD.size * 2.4, 1, 1);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshPhongMaterial({
    color: '#0e3a5c', emissive: '#071c2e', shininess: 120, specular: '#3d6b8f',
    transparent: true, opacity: 0.94,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = -4;
  mesh.name = 'sea';
  return mesh;
}

// ─── rivers (flat ribbons) ────────────────────────────────────────────────────
export function buildRibbon(pts: [number, number][], width: number, yOff: number, material: THREE.Material, uvScale = 6) {
  // compute cumulative distances
  const cum: number[] = [0];
  for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  const total = cum[cum.length - 1];
  const step = 26;
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  const verts: { x: number; z: number; y: number }[] = [];
  for (let s = 0; s <= total; s += step) {
    // find segment
    let i = 0;
    while (i < cum.length - 1 && cum[i + 1] < s) i++;
    const t = (s - cum[i]) / Math.max(1e-6, cum[i + 1] - cum[i]);
    const ax = pts[i][0], az = pts[i][1];
    const bx = pts[i + 1][0], bz = pts[i + 1][1];
    const dx = bx - ax, dz = bz - az;
    const len = Math.hypot(dx, dz) || 1;
    const nx = -dz / len, nz = dx / len;
    const cx = ax + dx * t, cz = az + dz * t;
    const y = terrainHeight(cx, cz) + yOff;
    verts.push({ x: cx + nx * width * 0.5, z: cz + nz * width * 0.5, y });
    verts.push({ x: cx - nx * width * 0.5, z: cz - nz * width * 0.5, y });
  }
  // recompute y conformed to terrain (3 verts approach)
  for (let i = 0; i < verts.length; i++) {
    verts[i].y = terrainHeight(verts[i].x, verts[i].z) + yOff;
  }
  for (let i = 0; i < verts.length; i += 2) {
    positions.push(verts[i].x, verts[i].y, verts[i].z, verts[i + 1].x, verts[i + 1].y, verts[i + 1].z);
    const sIdx = Math.floor(i / 2) * step;
    uvs.push(0, sIdx / uvScale, 1, sIdx / uvScale);
  }
  for (let i = 0; i < verts.length / 2 - 1; i++) {
    const i2 = i * 2;
    const i3 = i * 2 + 2;
    indices.push(i2, i2 + 1, i3, i3, i2 + 1, i3 + 1);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  const mesh = new THREE.Mesh(geo, material);
  mesh.receiveShadow = true;
  return mesh;
}

export function createRivers() {
  const group = new THREE.Group();
  const mat = new THREE.MeshPhongMaterial({ color: '#1c5b7a', emissive: '#06202f', shininess: 160, specular: '#6fb7d6', transparent: true, opacity: 0.92 });
  const ganga = buildRibbon([[-3600, -5200], [-3000, -4500], [-2700, -3300], [-1600, -3000], [-800, -2620], [500, -2620], [3400, -2050], [6800, -1300], [12000, -1400]], 42, 0.45, mat, 9);
  const yamuna = buildRibbon([[-3300, -6200], [-3000, -5100], [-3600, -4200], [-2700, -3300], [-1600, -2900], [-800, -2620]], 26, 0.45, mat, 9);
  const brahmaputra = buildRibbon([[6400, -8200], [5400, -6800], [4800, -5000], [4700, -3400], [5600, -1400], [6800, -1300]], 30, 0.45, mat, 9);
  group.add(ganga, yamuna, brahmaputra);
  group.name = 'rivers';
  return group;
}

// ─── clouds, stars, sun sprite ───────────────────────────────────────────────
function softCircleTexture(inner: string, outer: string, size = 128) {
  const cnv = document.createElement('canvas');
  cnv.width = cnv.height = size;
  const ctx = cnv.getContext('2d')!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, inner);
  g.addColorStop(0.55, outer);
  g.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(cnv);
  tex.needsUpdate = true;
  return tex;
}

export function createClouds(count = 18) {
  const tex = softCircleTexture('rgba(255,255,255,0.85)', 'rgba(255,255,255,0.35)', 256);
  const group = new THREE.Group();
  for (let i = 0; i < count; i++) {
    const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, opacity: 0.55, depthWrite: false });
    const s = new THREE.Sprite(mat);
    const r = WORLD.half * 1.1;
    const ang = (i / count) * Math.PI * 2 + hash(i, 7) * 0.9;
    const rad = (0.15 + hash(i, 13) * 0.85) * r;
    s.position.set(Math.cos(ang) * rad, 320 + hash(i, 21) * 160, Math.sin(ang) * rad);
    const sc = 320 + hash(i, 31) * 380;
    s.scale.set(sc, sc * 0.42, 1);
    group.add(s);
  }
  group.name = 'clouds';
  return group;
}

export function createStars() {
  const N = 500;
  const pos = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) {
    const ang = hash(i, 3) * Math.PI * 2;
    const elev = 0.12 + hash(i, 5) * 0.85;
    const r = 12500;
    pos[i * 3] = Math.cos(ang) * r;
    pos[i * 3 + 1] = Math.sin(elev * Math.PI * 0.5) * 11800;
    pos[i * 3 + 2] = Math.sin(ang) * r;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const mat = new THREE.PointsMaterial({ color: '#cfe0ff', size: 26, sizeAttenuation: false, transparent: true, opacity: 0, depthWrite: false });
  const pts = new THREE.Points(geo, mat);
  pts.name = 'stars';
  return pts;
}

export function createSunSprite() {
  const tex = softCircleTexture('rgba(255,244,200,1)', 'rgba(255,214,120,0.55)', 256);
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
  const s = new THREE.Sprite(mat);
  s.scale.set(1400, 1400, 1);
  s.name = 'sun';
  return s;
}
