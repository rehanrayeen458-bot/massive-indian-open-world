import * as THREE from 'three';

export interface CharacterOptions { skin: string; outfit: string; pants: string; hair: string; }

export class Character {
  group = new THREE.Group();
  torso!: THREE.Group;
  head!: THREE.Group;
  leftArm!: THREE.Group;
  rightArm!: THREE.Group;
  leftLeg!: THREE.Group;
  rightLeg!: THREE.Group;

  constructor(opts: CharacterOptions) {
    const { skin, outfit, pants, hair } = opts;
    const skinM = new THREE.MeshStandardMaterial({ color: skin, roughness: 0.75 });
    const outfitM = new THREE.MeshStandardMaterial({ color: outfit, roughness: 0.8 });
    const pantsM = new THREE.MeshStandardMaterial({ color: pants, roughness: 0.9 });
    const hairM = new THREE.MeshStandardMaterial({ color: hair, roughness: 0.9 });
    const shoeM = new THREE.MeshStandardMaterial({ color: '#20232a', roughness: 0.6 });

    // hips/legs
    this.leftLeg = new THREE.Group();
    this.leftLeg.position.set(-0.16, 1.02, 0);
    const lLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.11, 0.95, 8), pantsM);
    lLeg.position.y = -0.48;
    const lShoe = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.12, 0.34), shoeM);
    lShoe.position.set(0, -0.98, 0.05);
    this.leftLeg.add(lLeg, lShoe);

    this.rightLeg = new THREE.Group();
    this.rightLeg.position.set(0.16, 1.02, 0);
    const rLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.11, 0.95, 8), pantsM);
    rLeg.position.y = -0.48;
    const rShoe = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.12, 0.34), shoeM);
    rShoe.position.set(0, -0.98, 0.05);
    this.rightLeg.add(rLeg, rShoe);

    // torso
    this.torso = new THREE.Group();
    this.torso.position.y = 1.02;
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.30, 0.55, 6, 12), outfitM);
    body.position.y = 0.38;
    body.castShadow = true;
    // vest accent
    const vest = new THREE.Mesh(new THREE.CylinderGeometry(0.315, 0.3, 0.5, 12), new THREE.MeshStandardMaterial({ color: '#1c1f26', roughness: 0.6 }));
    vest.position.y = 0.36;
    this.torso.add(body, vest);

    // arms (pivot at shoulder)
    this.leftArm = new THREE.Group();
    this.leftArm.position.set(-0.42, 0.68, 0);
    const la = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.52, 4, 8), outfitM);
    la.position.y = -0.33;
    const lHand = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), skinM);
    lHand.position.y = -0.66;
    this.leftArm.add(la, lHand);

    this.rightArm = new THREE.Group();
    this.rightArm.position.set(0.42, 0.68, 0);
    const ra = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.52, 4, 8), outfitM);
    ra.position.y = -0.33;
    const rHand = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), skinM);
    rHand.position.y = -0.66;
    this.rightArm.add(ra, rHand);

    // head
    this.head = new THREE.Group();
    this.head.position.y = 0.92;
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.21, 16, 12), skinM);
    skull.castShadow = true;
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.23, 16, 10, 0, Math.PI * 2, 0, Math.PI * 0.52), hairM);
    cap.position.y = 0.05;
    cap.rotation.x = -0.18;
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.225, 0.035, 8, 16), new THREE.MeshStandardMaterial({ color: '#f5b544', roughness: 0.4, metalness: 0.6 }));
    band.rotation.x = Math.PI / 2;
    band.position.y = 0.06;
    const scarf = new THREE.Mesh(new THREE.CylinderGeometry(0.20, 0.24, 0.1, 10), new THREE.MeshStandardMaterial({ color: '#c0392b', roughness: 0.8 }));
    scarf.position.y = -0.22;
    this.head.add(skull, cap, band, scarf);

    this.torso.add(this.leftArm, this.rightArm, this.head);

    this.group.add(this.leftLeg, this.rightLeg, this.torso);
    this.group.traverse((o) => { if (o instanceof THREE.Mesh) o.castShadow = true; });
  }

  // animate limbs
  animate(state: 'idle' | 'walk' | 'run', phase: number) {
    const amp = state === 'idle' ? 0 : state === 'run' ? 0.95 : 0.55;
    const swing = Math.sin(phase) * amp;
    this.leftArm.rotation.x = swing;
    this.rightArm.rotation.x = -swing;
    this.leftLeg.rotation.x = -swing * 1.1;
    this.rightLeg.rotation.x = swing * 1.1;
    this.torso.position.y = 1.02 + Math.abs(Math.sin(phase)) * (state === 'idle' ? 0 : 0.06);
    this.head.rotation.y = Math.sin(phase * 0.5) * 0.08;
  }

  poseJump() {
    this.leftLeg.rotation.x = -0.9;
    this.rightLeg.rotation.x = 0.5;
    this.leftArm.rotation.x = -2.4;
    this.rightArm.rotation.x = 2.4;
  }

  poseIdleHandsUp() {
    this.leftArm.rotation.x = -2.8;
    this.rightArm.rotation.x = -2.8;
  }
}
