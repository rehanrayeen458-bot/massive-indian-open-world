// Tiny WebAudio synth — no external assets.
export class GameAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private engineOsc1: OscillatorNode | null = null;
  private engineOsc2: OscillatorNode | null = null;
  private engineGain: GainNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private rainGain: GainNode | null = null;
  private rainSource: AudioBufferSourceNode | null = null;

  ensure() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.55;
    this.master.connect(this.ctx.destination);

    // engine hum
    this.engineOsc1 = this.ctx.createOscillator();
    this.engineOsc1.type = 'sawtooth';
    this.engineOsc2 = this.ctx.createOscillator();
    this.engineOsc2.type = 'square';
    this.engineFilter = this.ctx.createBiquadFilter();
    this.engineFilter.type = 'lowpass';
    this.engineFilter.frequency.value = 320;
    this.engineGain = this.ctx.createGain();
    this.engineGain.gain.value = 0.0;
    const lfo = this.ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.value = 11;
    const lfoGain = this.ctx.createGain();
    lfoGain.gain.value = 30;
    lfo.connect(lfoGain);
    lfoGain.connect(this.engineFilter.frequency);
    lfo.start();
    this.engineOsc1.connect(this.engineFilter);
    this.engineOsc2.connect(this.engineFilter);
    this.engineFilter.connect(this.engineGain);
    this.engineGain.connect(this.master);
    this.engineOsc1.frequency.value = 50;
    this.engineOsc2.frequency.value = 75;
    this.engineOsc1.start();
    this.engineOsc2.start();
  }

  setEngine(speedNorm: number, throttle: number) {
    if (!this.ctx || !this.engineOsc1 || !this.engineOsc2 || !this.engineGain || !this.engineFilter) return;
    const t = this.ctx.currentTime;
    const base = 42 + speedNorm * 96;
    this.engineOsc1.frequency.setTargetAtTime(base, t, 0.08);
    this.engineOsc2.frequency.setTargetAtTime(base * 1.5 + 8, t, 0.08);
    this.engineFilter.frequency.setTargetAtTime(260 + speedNorm * 620 + throttle * 500, t, 0.12);
    this.engineGain.gain.setTargetAtTime(0.028 + speedNorm * 0.05 + throttle * 0.02, t, 0.1);
  }

  idleEngine() {
    if (!this.ctx || !this.engineGain) return;
    this.engineGain.gain.setTargetAtTime(0.016, this.ctx.currentTime, 0.2);
  }

  silenceEngine() {
    if (!this.ctx || !this.engineGain) return;
    this.engineGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.1);
  }

  setRain(on: boolean) {
    if (!this.ctx || !this.master) return;
    if (on && !this.rainSource) {
      const len = 2 * this.ctx.sampleRate;
      const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * 0.5;
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      src.loop = true;
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 1600;
      filter.Q.value = 0.35;
      const f2 = this.ctx.createBiquadFilter();
      f2.type = 'lowpass';
      f2.frequency.value = 4200;
      this.rainGain = this.ctx.createGain();
      this.rainGain.gain.value = 0.0;
      src.connect(filter); filter.connect(f2); f2.connect(this.rainGain); this.rainGain.connect(this.master);
      src.start();
      this.rainSource = src;
      this.rainGain.gain.setTargetAtTime(0.055, this.ctx.currentTime, 1.2);
    } else if (!on && this.rainSource) {
      this.rainGain?.gain.setTargetAtTime(0, this.ctx.currentTime, 0.8);
      const src = this.rainSource;
      setTimeout(() => { try { src.stop(); } catch {} }, 1200);
      this.rainSource = null;
      this.rainGain = null;
    }
  }

  chime() {
    if (!this.ctx || !this.master) return;
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, i) => this.tone(freq, 0.32, 'sine', 0.12, i * 0.11));
  }

  coin() {
    this.tone(880, 0.09, 'square', 0.08, 0);
    this.tone(1318.5, 0.18, 'square', 0.07, 0.08);
  }

  thud(intensity = 1) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime;
    const len = 0.16 * this.ctx.sampleRate;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 420;
    const g = this.ctx.createGain();
    g.gain.value = Math.min(0.6, 0.32 * intensity);
    src.connect(filter); filter.connect(g); g.connect(this.master);
    src.start(t);
  }

  whoosh() {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime;
    const len = 0.28 * this.ctx.sampleRate;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * Math.sin((i / len) * Math.PI);
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.Q.value = 1.4;
    filter.frequency.setValueAtTime(400, t);
    filter.frequency.exponentialRampToValueAtTime(2400, t + 0.25);
    const g = this.ctx.createGain();
    g.gain.value = 0.28;
    src.connect(filter); filter.connect(g); g.connect(this.master);
    src.start(t);
  }

  click() {
    this.tone(660, 0.06, 'sine', 0.1, 0);
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, delay: number) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    osc.connect(g); g.connect(this.master);
    osc.start(t); osc.stop(t + dur + 0.05);
  }

  setMuted(m: boolean) {
    if (!this.ctx || !this.master) return;
    this.master.gain.setTargetAtTime(m ? 0 : 0.55, this.ctx.currentTime, 0.1);
  }

  dispose() {
    try { this.engineOsc1?.stop(); this.engineOsc2?.stop(); this.rainSource?.stop(); } catch {}
    this.ctx?.close();
    this.ctx = null;
  }
}
