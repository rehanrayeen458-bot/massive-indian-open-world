import { useEffect, useMemo, useState } from 'react';
import {
  Play, Compass, Trophy, Gamepad2, X, MapPin, Gauge, Sparkles,
  Sun, CloudRain, Car, Footprints, Award, Zap,
} from 'lucide-react';
import { CITIES, VEHICLES } from '../game/data';

export interface CharacterCustom {
  skin: string; outfit: string; pants: string; hair: string; name: string;
}

export const SKIN_TONES = ['#8d5a3b', '#b5794e', '#c98f62', '#e0a878', '#eec298'];
export const OUTFIT_COLORS = ['#f5b544', '#138808', '#1e3a5f', '#c0392b', '#f0f0ec', '#7c4a2d', '#2b2f38', '#e8b30e'];
export const HAIR_COLORS = ['#141414', '#33241a', '#4e3320', '#6b4226', '#b8b8b8'];
export const PANTS_COLORS = ['#20232a', '#3a3226', '#2a3a4a', '#3d2a2a'];

export const DEFAULT_CUSTOM: CharacterCustom = {
  skin: '#b5794e', outfit: '#f5b544', pants: '#20232a', hair: '#1c1c1c', name: 'Rahul',
};

export interface HighScoreEntry {
  score: number; cities: number; total: number; km: number; topKmh: number; time: number; date: string; mode: string; initials: string;
}

export function loadCustom(): CharacterCustom {
  try {
    const raw = localStorage.getItem('indiaLifeCustom');
    if (raw) return { ...DEFAULT_CUSTOM, ...JSON.parse(raw) };
  } catch {}
  return DEFAULT_CUSTOM;
}
export function saveCustom(c: CharacterCustom) {
  try { localStorage.setItem('indiaLifeCustom', JSON.stringify(c)); } catch {}
}

export function loadHighScores(): HighScoreEntry[] {
  try {
    const raw = localStorage.getItem('indiaLifeHighScores');
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}
export function saveHighScore(e: Omit<HighScoreEntry, 'date'>) {
  const list = loadHighScores();
  list.push({ ...e, date: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) });
  list.sort((a, b) => b.score - a.score);
  const top = list.slice(0, 8);
  try { localStorage.setItem('indiaLifeHighScores', JSON.stringify(top)); } catch {}
  return top;
}

const FEATURED = CITIES.filter((c) => c.featured).length;

export default function Menu({
  onStart,
}: {
  onStart: (mode: 'tour' | 'free') => void;
}) {
  const [custom, setCustom] = useState<CharacterCustom>(loadCustom);
  const [tab, setTab] = useState<'customize' | 'highscores' | 'howto'>('customize');
  const [showMenuCard, setShowMenuCard] = useState(true);

  useEffect(() => { saveCustom(custom); }, [custom]);

  const scores = useMemo(loadHighScores, []);
  const totalTrips = useMemo(() => CITIES.length, []);

  return (
    <div className="relative h-full w-full overflow-hidden">
      {/* backdrop */}
      <img src="/images/hero.jpg" alt="" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-b from-[#05070f]/70 via-[#0b1020]/72 to-[#05070f]/94" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_25%,rgba(4,6,14,0.65)_100%)]" />

      <div className="relative z-10 flex h-full flex-col">
        {/* top bar */}
        <header className="flex items-center justify-between px-5 pt-5 sm:px-10">
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-amber-400 to-orange-700 shadow-lg shadow-amber-900/50">
              <Compass className="h-6 w-6 text-[#241300]" strokeWidth={2.4} />
            </div>
            <div>
              <div className="font-display text-lg leading-none tracking-widest text-[#ffe6a8]">INDIA LIFE</div>
              <div className="text-[10px] uppercase tracking-[0.3em] text-white/55">Open World</div>
            </div>
          </div>
          <div className="hidden items-center gap-2 rounded-full glass-soft px-4 py-2 text-xs text-white/80 sm:flex">
            <Trophy className="h-4 w-4 text-amber-400" />
            <span>{scores[0] ? `Best ${scores[0].score.toLocaleString()}` : 'No records yet'}</span>
          </div>
        </header>

        {/* hero */}
        <div className="flex flex-1 flex-col items-center justify-center px-4 pt-4 text-center">
          <div className="mb-4 flex items-center gap-3">
            <span className="tricolor h-2 w-20 rounded-full" />
            <span className="rounded-full border border-white/20 px-4 py-1 text-[10px] font-semibold uppercase tracking-[0.24em] text-white/85">
              28 states · 8 UTs · 50 cities
            </span>
            <span className="tricolor h-2 w-20 rounded-full" />
          </div>
          <h1 className="font-display text-[19vw] leading-[0.85] sm:text-[7.5rem]">
            <span className="text-gold-grad">INDIA</span>
          </h1>
          <h1 className="font-display -mt-3 text-[13vw] leading-[0.85] text-white sm:text-[5.4rem]">
            LIFE<span className="text-amber-400">.</span>
          </h1>
          <p className="mt-4 max-w-xl text-sm font-light text-white/80 sm:text-base">
            A massive open-world adventure across the subcontinent — Himalaya roads, Thar dunes,
            backwaters, metro highways and forest ghats. Drive. Explore. Discover.
          </p>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button onClick={() => onStart('tour')} className="btn-gold group flex items-center gap-3 rounded-2xl px-8 py-4 text-sm uppercase">
              <Play className="h-5 w-5 fill-current transition-transform group-hover:scale-125" />
              Start Grand Tour
            </button>
            <button onClick={() => onStart('free')} className="btn-ghost flex items-center gap-2 rounded-2xl px-6 py-4 text-sm font-semibold uppercase tracking-wider">
              <Compass className="h-5 w-5 text-amber-300" />
              Free Roam
            </button>
          </div>

          <div className="mt-5 flex flex-wrap justify-center gap-2">
            <button onClick={() => { setTab('customize'); setShowMenuCard(true); }} className="btn-ghost rounded-full px-4 py-2 text-xs uppercase tracking-widest">Customize</button>
            <button onClick={() => { setTab('howto'); setShowMenuCard(true); }} className="btn-ghost rounded-full px-4 py-2 text-xs uppercase tracking-widest">How to Play</button>
            <button onClick={() => { setTab('highscores'); setShowMenuCard(true); }} className="btn-ghost rounded-full px-4 py-2 text-xs uppercase tracking-widest">High Scores</button>
          </div>
        </div>

        {/* stat strip */}
        <div className="mx-auto mb-5 grid w-full max-w-4xl grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/10 bg-white/5 sm:grid-cols-4">
          {[
            { icon: MapPin, label: 'Cities', value: `${totalTrips}` },
            { icon: Car, label: 'Featured', value: `${FEATURED}` },
            { icon: Gauge, label: 'Fastest car', value: `410 km/h` },
            { icon: Zap, label: 'Weather', value: 'Day · Rain · Night' },
          ].map((s) => (
            <div key={s.label} className="flex items-center gap-3 bg-[#0b1122]/80 px-4 py-3">
              <s.icon className="h-5 w-5 shrink-0 text-amber-400" />
              <div>
                <div className="text-[10px] uppercase tracking-widest text-white/50">{s.label}</div>
                <div className="text-sm font-semibold text-white">{s.value}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* customize / highscores / howto modal */}
      {showMenuCard && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/65 p-4" onClick={() => setShowMenuCard(false)}>
          <div className="glass w-full max-w-3xl rounded-3xl p-6 sm:p-8" onClick={(e) => e.stopPropagation()}>
            <div className="mb-5 flex items-center justify-between">
              <h2 className="font-display text-3xl tracking-wide text-amber-300">
                {tab === 'customize' ? 'Character Studio' : tab === 'highscores' ? 'High Scores' : 'How to Play'}
              </h2>
              <button className="btn-ghost rounded-full p-2" onClick={() => setShowMenuCard(false)} aria-label="Close"><X className="h-5 w-5" /></button>
            </div>

            {tab === 'customize' && (
              <div className="space-y-5">
                <div>
                  <div className="mb-2 text-[11px] font-semibold uppercase tracking-widest text-white/60">Name</div>
                  <input
                    value={custom.name}
                    maxLength={16}
                    onChange={(e) => setCustom({ ...custom, name: e.target.value })}
                    className="w-full rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-lg font-semibold text-white outline-none focus:border-amber-400/60"
                  />
                </div>
                {[
                  { key: 'skin' as const, label: 'Skin tone', colors: SKIN_TONES },
                  { key: 'outfit' as const, label: 'Outfit', colors: OUTFIT_COLORS },
                  { key: 'pants' as const, label: 'Pants', colors: PANTS_COLORS },
                  { key: 'hair' as const, label: 'Hair', colors: HAIR_COLORS },
                ].map((row) => (
                  <div key={row.key}>
                    <div className="mb-2 text-[11px] font-semibold uppercase tracking-widest text-white/60">{row.label}</div>
                    <div className="flex flex-wrap gap-2">
                      {row.colors.map((c) => (
                        <button
                          key={c}
                          onClick={() => setCustom({ ...custom, [row.key]: c })}
                          className={`h-10 w-10 rounded-full border-2 transition-transform hover:scale-110 ${custom[row.key] === c ? 'border-amber-400 ring-2 ring-amber-400/40' : 'border-white/20'}`}
                          style={{ backgroundColor: c }}
                        />
                      ))}
                    </div>
                  </div>
                ))}
                <div className="rounded-2xl bg-amber-400/10 p-4 text-sm leading-relaxed text-white/80">
                  Your look is saved locally and locked in when the run starts. Pick something that turns heads at the India Gate.
                </div>
              </div>
            )}

            {tab === 'highscores' && (
              <div className="space-y-2">
                {scores.length === 0 && (
                  <div className="flex flex-col items-center gap-3 py-10 text-center">
                    <Trophy className="h-10 w-10 text-white/30" />
                    <p className="text-white/60">No scores yet — run the Grand Tour and set the record.</p>
                  </div>
                )}
                {scores.map((s, i) => (
                  <div key={i} className="flex items-center gap-4 rounded-2xl bg-white/5 px-4 py-3">
                    <div className={`font-display w-10 text-center text-2xl ${i === 0 ? 'text-amber-400' : 'text-white/50'}`}>{i + 1}</div>
                    <div className="flex-1">
                      <div className="font-semibold text-white">{s.initials}</div>
                      <div className="text-[11px] uppercase tracking-wider text-white/45">{s.cities}/{s.total} cities · {s.km.toFixed(1)} km · {s.mode}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-display text-2xl text-amber-300">{s.score.toLocaleString()}</div>
                      <div className="text-[10px] text-white/40">{s.date}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {tab === 'howto' && (
              <div className="grid gap-3 text-sm text-white/85 sm:grid-cols-2">
                {[
                  { icon: Gamepad2, title: 'Drive', text: 'WASD / arrows + Shift for run. Space = handbrake (or jump on foot). E = enter / exit vehicle.' },
                  { icon: MapPin, title: 'Explore', text: 'Discover all 50 cities across 28 states + 8 union territories for +500 pts each.' },
                  { icon: Car, title: 'Garages', text: 'Visit garages marked with a badge. Swap between Thar, Innova, Fortuner, Lamborghini and more.' },
                  { icon: Sparkles, title: 'Scoring', text: '+0.12 per metre driven · +100 petrol pump · +2.5/s above 180 km/h · +500 city discovery.' },
                  { icon: Sun, title: 'Day & Night', text: 'Time cycles every 10 minutes. Night brings headlights, lit windows and cooler fog.' },
                  { icon: CloudRain, title: 'Weather', text: 'Auto-cycles between clear, monsoon and dusk. Rain slows grip, clears on its own.' },
                  { icon: Footprints, title: 'On foot', text: 'Walk with WASD, run with Shift, jump with Space. Exit anytime with E.' },
                  { icon: Award, title: 'Grand Tour', text: '10-minute shift, score fast, discover every city — beat your high score table.' },
                ].map((c) => (
                  <div key={c.title} className="rounded-2xl bg-white/5 p-4">
                    <div className="mb-2 flex items-center gap-2 font-semibold text-amber-300"><c.icon className="h-4 w-4" />{c.title}</div>
                    <p className="text-[13px] leading-relaxed text-white/75">{c.text}</p>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {VEHICLES.slice(0, 4).map((v) => (
                <div key={v.key} className="rounded-xl bg-black/30 px-3 py-2 text-center">
                  <div className="text-[10px] uppercase tracking-wider text-white/50">{v.class}</div>
                  <div className="text-xs font-semibold text-amber-200">{v.name}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
