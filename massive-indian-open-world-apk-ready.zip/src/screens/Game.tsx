import { useEffect, useMemo, useRef, useState, useCallback } from 'react';
import {
  Pause, Play, RotateCcw, Home, Sun, CloudRain, CloudSun, Trophy, MapPin, Gauge,
  Clock, Wind, Navigation, Volume2, VolumeX, Flag, X, Check,
  Wrench, Sparkles, ChevronUp, ArrowUp,
} from 'lucide-react';
import { Engine, type HudData, type GameResult } from '../game/engine';
import { VEHICLES, VEHICLE_COLORS, type CityDef, type VehicleKey } from '../game/data';
import { loadHighScores, saveHighScore, type CharacterCustom } from './Menu';

const IS_TOUCH = typeof window !== 'undefined' && (window.matchMedia?.('(pointer: coarse)').matches || /Android|iPhone|iPad/i.test(navigator.userAgent));

function fmtTime(s: number) {
  const t = Math.max(0, Math.floor(s));
  const m = Math.floor(t / 60), r = t % 60;
  return `${m}:${r.toString().padStart(2, '0')}`;
}

function formatHour(h: number) {
  const hh = Math.floor(h) % 24;
  const ap = hh >= 12 ? 'PM' : 'AM';
  const h12 = hh % 12 === 0 ? 12 : hh % 12;
  return `${h12}:${Math.floor((h - Math.floor(h)) * 60).toString().padStart(2, '0')} ${ap}`;
}

interface Toast { id: number; msg: string; kind: 'gold' | 'green' | 'red' | 'info'; }

// ─── touch controls ────────────────────────────────────────────────────────────
function Joystick({ onChange }: { onChange: (v: { x: number; y: number }) => void }) {
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const track = useRef<HTMLDivElement>(null);
  const id = useRef<number | null>(null);

  const handle = (e: React.PointerEvent) => {
    if (!track.current) return;
    const rect = track.current.getBoundingClientRect();
    const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
    let dx = e.clientX - cx, dy = e.clientY - cy;
    const max = rect.width / 2 - 30;
    const d = Math.hypot(dx, dy);
    if (d > max) { dx = (dx / d) * max; dy = (dy / d) * max; }
    setKnob({ x: dx, y: dy });
    onChange({ x: dx / max, y: -dy / max });
  };

  return (
    <div
      ref={track}
      className="touch-btn relative h-36 w-36 rounded-full"
      onPointerDown={(e) => { id.current = e.pointerId; (e.target as HTMLElement).setPointerCapture?.(e.pointerId); handle(e); }}
      onPointerMove={(e) => { if (id.current === e.pointerId) handle(e); }}
      onPointerUp={() => { id.current = null; setKnob({ x: 0, y: 0 }); onChange({ x: 0, y: 0 }); }}
      onPointerCancel={() => { id.current = null; setKnob({ x: 0, y: 0 }); onChange({ x: 0, y: 0 }); }}
    >
      <div className="absolute left-1/2 top-1/2 h-16 w-16 -translate-x-1/2 -translate-y-1/2 rounded-full border border-amber-300/30" />
      <div
        className="absolute left-1/2 top-1/2 h-14 w-14 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-br from-amber-300 to-orange-600 shadow-lg shadow-black/50"
        style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
      />
    </div>
  );
}

function SteerSlider({ onChange }: { onChange: (v: number) => void }) {
  const [value, setValue] = useState(0);
  const track = useRef<HTMLDivElement>(null);
  const id = useRef<number | null>(null);

  const handle = (e: React.PointerEvent) => {
    if (!track.current) return;
    const rect = track.current.getBoundingClientRect();
    const v = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const c = Math.max(-1, Math.min(1, v));
    setValue(c);
    onChange(c);
  };

  return (
    <div
      ref={track}
      className="touch-btn relative h-16 w-full rounded-2xl"
      onPointerDown={(e) => { id.current = e.pointerId; e.currentTarget.setPointerCapture?.(e.pointerId); handle(e); }}
      onPointerMove={(e) => { if (id.current === e.pointerId) handle(e); }}
      onPointerUp={() => { id.current = null; setValue(0); onChange(0); }}
      onPointerCancel={() => { id.current = null; setValue(0); onChange(0); }}
    >
      <div className="absolute left-1/2 top-1/2 h-10 w-px -translate-x-1/2 -translate-y-1/2 bg-white/20" />
      <div
        className="absolute top-1/2 h-12 w-16 -translate-y-1/2 rounded-xl border border-amber-300/40 bg-gradient-to-b from-[#1d2438] to-[#11151f] shadow-md"
        style={{ left: `calc(${(value * 0.5 + 0.5) * 100}% - 32px)` }}
      >
        <div className="grid h-full place-items-center text-amber-300"><Navigation className="h-5 w-5" /></div>
      </div>
    </div>
  );
}

function HoldButton({ onHold, onRelease, className = '', children, label }: {
  onHold: () => void; onRelease: () => void; className?: string; children: React.ReactNode; label?: string;
}) {
  return (
    <button
      className={`touch-btn flex flex-col items-center justify-center rounded-2xl font-display uppercase ${className}`}
      onPointerDown={(e) => { e.preventDefault(); e.currentTarget.setPointerCapture?.(e.pointerId); onHold(); }}
      onPointerUp={onRelease}
      onPointerCancel={onRelease}
      onPointerLeave={onRelease}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
      {label && <span className="text-[9px] tracking-[0.2em] text-white/60">{label}</span>}
    </button>
  );
}

// ─── main game screen ──────────────────────────────────────────────────────────
export default function Game({ mode, character, onExit, onRestart }: {
  mode: 'tour' | 'free';
  character: CharacterCustom;
  onExit: () => void;
  onRestart: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const minimapRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const [hud, setHud] = useState<HudData | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [paused, setPaused] = useState(false);
  const [garage, setGarage] = useState<{ open: boolean; name: string }>({ open: false, name: '' });
  const [result, setResult] = useState<GameResult | null>(null);
  const [banner, setBanner] = useState<{ city: CityDef; key: number } | null>(null);
  const [weatherMode, setWeatherMode] = useState<'auto' | 'clear' | 'rain'>('auto');
  const [muted, setMuted] = useState(false);
  const [customVehicleKey, setCustomVehicleKey] = useState('swift');
  const [customColor, setCustomColor] = useState('#c0c8cc');
  const [newHighScore, setNewHighScore] = useState(false);
  const [loading, setLoading] = useState(true);
  const toastId = useRef(0);
  const garageRef = useRef(false);

  const addToast = useCallback((msg: string, kind: Toast['kind'] = 'info') => {
    const id = ++toastId.current;
    setToasts((t) => [...t.slice(-3), { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2800);
  }, []);

  useEffect(() => {
    if (!canvasRef.current) return;
    let engine: Engine | null = null;
    let cancelled = false;
    const t = setTimeout(() => {
      if (cancelled || !canvasRef.current) return;
      const e = new Engine(canvasRef.current!, {
        mode,
        character: { skin: character.skin, outfit: character.outfit, pants: character.pants, hair: character.hair, name: character.name },
        weatherMode: 'auto',
        onHud: setHud,
        onGameOver: (r) => {
          setResult(r);
          e.setPaused(true);
          const best = loadHighScores();
          const entry = { score: r.score, cities: r.citiesFound, total: r.totalCities, km: r.distanceKm, topKmh: r.topSpeedKmh, time: r.timePlayed, mode: mode === 'tour' ? 'Tour' : 'Free Roam', initials: character.name.slice(0, 4).toUpperCase() || 'P1L' };
          saveHighScore(entry);
          setNewHighScore(!best.length || best[0].score < r.score);
        },
        onToast: (msg, kind) => addToast(msg, kind),
        onGarage: (open) => setGarage((g) => { garageRef.current = open; return { open, name: open ? (hudRef.current?.nearPrompt?.replace('Enter ', '') ?? 'Garage') : g.name }; }),
        onDiscover: (city) => {
          setBanner({ city, key: Date.now() });
          setTimeout(() => setBanner(null), 3400);
        },
        onEscape: () => {
          if (garageRef.current) { e.closeGaragePublic(); return; }
          togglePause();
        },
      });
      engine = e;
      engineRef.current = e;
      if (minimapRef.current) engine.setMinimapCanvas(minimapRef.current);
      engine.start();
      setLoading(false);
    }, 90);
    return () => {
      cancelled = true;
      clearTimeout(t);
      if (engine) engine.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const hudRef = useRef<HudData | null>(null);
  hudRef.current = hud;

  useEffect(() => { garageRef.current = garage.open; }, [garage.open]);

  const togglePause = useCallback(() => {
    if (garageRef.current) return;
    setPaused((p) => {
      const next = !p;
      engineRef.current?.setPaused(next);
      return next;
    });
  }, []);

  const cycleWeather = useCallback(() => {
    setWeatherMode((m) => {
      const next = m === 'auto' ? 'rain' : m === 'rain' ? 'clear' : 'auto';
      engineRef.current?.setWeatherMode(next);
      return next;
    });
  }, []);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      engineRef.current?.setMuted(!m);
      return !m;
    });
  }, []);

  const interact = useCallback(() => engineRef.current?.pressInteract(), []);

  const scores = useMemo(loadHighScores, [result]);

  // apply current vehicle defaults in garage
  useEffect(() => {
    const st = engineRef.current?.getVehicleState();
    if (st) { setCustomVehicleKey(st.key); setCustomColor(st.color); }
  }, [garage.open]);

  const isTouch = IS_TOUCH;

  return (
    <div className="relative h-full w-full overflow-hidden bg-black">
      <canvas ref={canvasRef} className="game-canvas" />

      {/* ── Loading overlay ── */}
      {loading && (
        <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-[#05070f]">
          <div className="tricolor h-1.5 w-40 rounded-full" />
          <div className="font-display mt-6 text-4xl tracking-widest text-amber-300">BUILDING INDIA</div>
          <div className="mt-3 max-w-xs text-center text-xs leading-relaxed text-white/55">
            Raising mountains, planting forests, laying highways…
          </div>
          <div className="mt-6 h-1 w-56 overflow-hidden rounded-full bg-white/10">
            <div className="shimmer h-full w-1/2" />
          </div>
        </div>
      )}

      {/* ── HUD overlay ── */}
      <div className="pointer-events-none absolute inset-0 z-10">
        {/* top-left: score */}
        <div className="absolute left-3 top-3 sm:left-5 sm:top-5">
          <div className="glass rounded-2xl px-4 py-3">
            <div className="text-[9px] font-semibold uppercase tracking-[0.25em] text-amber-300/90">Score</div>
            <div className="font-display text-4xl leading-none text-amber-300">{(hud?.score ?? 0).toLocaleString()}</div>
            <div className="mt-1 flex gap-3 text-[10px] font-medium text-white/70">
              <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{hud?.discovered ?? 0}/{hud?.total ?? 0}</span>
              <span className="flex items-center gap-1"><Gauge className="h-3 w-3" />{hud?.distanceKm.toFixed(1) ?? '0.0'} km</span>
            </div>
          </div>
        </div>

        {/* top-center: mode + timer */}
        <div className="absolute left-1/2 top-3 -translate-x-1/2 sm:top-5">
          <div className="glass flex items-center gap-3 rounded-2xl px-5 py-2.5">
            <span className={`rounded-full px-3 py-0.5 text-[10px] font-bold uppercase tracking-widest ${mode === 'tour' ? 'bg-amber-400/20 text-amber-300' : 'bg-emerald-400/20 text-emerald-300'}`}>
              {mode === 'tour' ? 'Grand Tour' : 'Free Roam'}
            </span>
            {mode === 'tour' ? (
              <span className={`flex items-center gap-1.5 text-lg font-bold tabular-nums ${hud && hud.timeLeft < 60 ? 'text-red-400 animate-blink' : 'text-white'}`}>
                <Clock className="h-4 w-4 text-amber-300" />
                {fmtTime(hud?.timeLeft ?? 600)}
              </span>
            ) : (
              <span className="text-sm font-semibold text-white/80">{formatHour(hud?.hour ?? 9.5)}</span>
            )}
            <span className="flex items-center gap-1.5 border-l border-white/10 pl-3 text-xs text-white/70">
              <ArrowUp className="h-3.5 w-3.5 text-amber-300" style={{ transform: `rotate(${(-(hud?.nearest?.bearing ?? 0)) * 180 / Math.PI}deg)` }} />
              {hud?.nearest ? (
                <span>{hud.nearest.name} · {hud.nearest.km.toFixed(1)} km</span>
              ) : (
                <span className="text-emerald-300">All cities discovered!</span>
              )}
            </span>
          </div>
        </div>

        {/* top-right: weather + pause + mute */}
        <div className="absolute right-3 top-3 flex flex-col items-end gap-2 sm:right-5 sm:top-5">
          <div className="pointer-events-auto flex gap-2">
            <button onClick={cycleWeather} className="touch-btn grid h-11 w-11 place-items-center rounded-xl" aria-label="Cycle weather">
              {weatherMode === 'auto' ? <CloudSun className="h-5 w-5 text-amber-200" /> : weatherMode === 'rain' ? <CloudRain className="h-5 w-5 text-sky-300" /> : <Sun className="h-5 w-5 text-amber-300" />}
            </button>
            <button onClick={toggleMute} className="touch-btn grid h-11 w-11 place-items-center rounded-xl" aria-label="Toggle sound">
              {muted ? <VolumeX className="h-5 w-5 text-white/70" /> : <Volume2 className="h-5 w-5 text-amber-200" />}
            </button>
            <button onClick={togglePause} className="touch-btn grid h-11 w-11 place-items-center rounded-xl" aria-label="Pause">
              {paused ? <Play className="h-5 w-5 text-amber-300" /> : <Pause className="h-5 w-5 text-white/85" />}
            </button>
          </div>
          <div className="rounded-full px-3 py-1 text-[9px] font-semibold uppercase tracking-[0.22em] text-white/60">
            {weatherMode === 'auto' ? 'Weather · Auto' : weatherMode === 'rain' ? 'Weather · Rain' : 'Weather · Clear'}
          </div>
        </div>

        {/* toasts */}
        <div className="absolute left-1/2 top-20 flex -translate-x-1/2 flex-col items-center gap-2 sm:top-22">
          {toasts.map((t) => (
            <div key={t.id} className={`animate-toast rounded-full px-5 py-2 text-xs font-semibold shadow-xl backdrop-blur-md ${t.kind === 'gold' ? 'bg-amber-400/90 text-amber-950' : t.kind === 'green' ? 'bg-emerald-500/90 text-emerald-950' : t.kind === 'red' ? 'bg-red-500/90 text-red-50' : 'bg-slate-800/90 text-white'}`}>
              {t.msg}
            </div>
          ))}
        </div>

        {/* discovery banner */}
        {banner && (
          <div key={banner.key} className="animate-toast absolute inset-x-0 top-[30%] flex flex-col items-center">
            <div className="flex items-center gap-2 rounded-full bg-black/60 px-6 py-1.5 text-[11px] font-bold uppercase tracking-[0.3em] text-amber-300 backdrop-blur-md">
              <Sparkles className="h-4 w-4" /> City Discovered
            </div>
            <div className="font-display mt-2 text-6xl leading-none tracking-wide text-white drop-shadow-[0_6px_24px_rgba(0,0,0,0.9)] sm:text-7xl">
              {banner.city.name.toUpperCase()}
            </div>
            <div className="mt-2 text-sm font-semibold text-white/85">{banner.city.state} · +500 pts</div>
          </div>
        )}

        {/* bottom-left: minimap */}
        <div className="absolute bottom-3 left-3 sm:bottom-5 sm:left-5">
          <div className="relative overflow-hidden rounded-full border-2 border-amber-400/40 shadow-2xl shadow-black/60">
            <canvas ref={minimapRef} width={232} height={232} className="block h-40 w-40 sm:h-52 sm:w-52" />
            <div className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 rounded-full bg-black/60 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-[0.24em] text-amber-200/90 backdrop-blur-sm">GPS</div>
          </div>
        </div>

        {/* bottom-right: speed */}
        <div className="absolute bottom-3 right-3 flex flex-col items-end gap-2 sm:bottom-5 sm:right-5">
          <div className="glass rounded-2xl px-5 py-3 text-right">
            <div className="font-display text-5xl leading-none text-white tabular-nums">
              {Math.round(hud?.speedKmh ?? 0)}
              <span className="ml-1 align-middle text-base font-normal tracking-wider text-white/50">km/h</span>
            </div>
            <div className="mt-0.5 text-[10px] uppercase tracking-widest text-white/45">
              {hud?.inVehicle ? hud.vehicleName : character.name} · {hud?.offroad ? 'Off-road' : hud?.inVehicle ? 'On-road' : 'On foot'}
            </div>
            {hud?.handbrake && <div className="mt-1 inline-flex items-center gap-1 rounded-full bg-red-500/25 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-red-300">Handbrake</div>}
          </div>
        </div>

        {/* center prompt */}
        {hud?.nearPrompt && !result && (
          <button
            onClick={interact}
            className="pointer-events-auto absolute bottom-[36%] left-1/2 -translate-x-1/2 rounded-full border border-amber-300/50 bg-black/70 px-6 py-2.5 text-xs font-bold uppercase tracking-[0.2em] text-amber-200 shadow-xl backdrop-blur-md"
          >
            {isTouch ? 'TAP' : 'PRESS'} <span className="rounded bg-amber-400 px-1.5 py-0.5 text-amber-950">E</span> · {hud.nearPrompt}
          </button>
        )}
        {hud?.inVehicle === false && !hud?.nearPrompt && !result && (
          <button
            onClick={interact}
            className="pointer-events-auto absolute bottom-[36%] left-1/2 -translate-x-1/2 rounded-full border border-white/20 bg-black/60 px-6 py-2.5 text-xs font-semibold uppercase tracking-[0.2em] text-white/85 backdrop-blur-md"
          >
            {isTouch ? 'TAP' : 'PRESS'} <span className="rounded bg-white/20 px-1.5 py-0.5">E</span> · Get in your {hud?.vehicleName ?? 'car'}
          </button>
        )}

        {/* touch controls */}
        {isTouch && !result && !garage.open && (
          <div className="pointer-events-auto absolute inset-x-0 bottom-0 z-20 flex items-end justify-between p-4 pb-6">
            <div className="pb-2">
              {hud?.inVehicle ? (
                <div className="w-40 sm:w-64"><SteerSlider onChange={(v) => engineRef.current?.setTouch({ steer: v })} /></div>
              ) : (
                <Joystick onChange={(v) => engineRef.current?.setTouch({ move: v })} />
              )}
            </div>
            <div className="flex items-end gap-2 pb-2">
              {!hud?.inVehicle && (
                <HoldButton
                  label="Jump"
                  className="h-16 w-16"
                  onHold={() => engineRef.current?.setTouch({ jump: true })}
                  onRelease={() => engineRef.current?.setTouch({ jump: false })}
                >
                  <ChevronUp className="h-6 w-6 text-amber-200" />
                </HoldButton>
              )}
              <HoldButton
                label="Brake / Rev"
                className="h-20 w-16 text-sm text-red-300"
                onHold={() => engineRef.current?.setTouch({ brake: 1 })}
                onRelease={() => engineRef.current?.setTouch({ brake: 0 })}
              >
                <Flag className="h-6 w-6" />
              </HoldButton>
              {hud?.inVehicle && (
                <HoldButton
                  label="Handbrake"
                  className="h-16 w-16 text-xs text-orange-300"
                  onHold={() => engineRef.current?.setTouch({ handbrake: true })}
                  onRelease={() => engineRef.current?.setTouch({ handbrake: false })}
                >
                  <ArrowUp className="h-5 w-5" />
                </HoldButton>
              )}
              <HoldButton
                label="Gas"
                className="h-24 w-16 text-sm text-emerald-300"
                onHold={() => engineRef.current?.setTouch({ throttle: 1 })}
                onRelease={() => engineRef.current?.setTouch({ throttle: 0 })}
              >
                <Gauge className="h-7 w-7" />
              </HoldButton>
              <HoldButton
                label="Use / E"
                className="h-16 w-16 text-xs text-amber-200"
                onHold={() => interact()}
                onRelease={() => {}}
              >
                <Sparkles className="h-5 w-5" />
              </HoldButton>
            </div>
          </div>
        )}

        {/* keyboard hint bottom-center (desktop only) */}
        {!isTouch && (
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-black/45 px-4 py-1.5 text-[10px] font-medium uppercase tracking-[0.2em] text-white/60 backdrop-blur-md">
            {hud?.inVehicle ? 'W/S speed · A/D steer · Space handbrake · E exit' : 'WASD walk · Shift run · Space jump · E enter car'}
          </div>
        )}
      </div>

      {/* ── Garage modal ── */}
      {garage.open && hud && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/70 p-3 backdrop-blur-sm">
          <div className="glass max-h-[88vh] w-full max-w-3xl overflow-y-auto rounded-3xl p-5 sm:p-7">
            <div className="mb-4 flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.3em] text-amber-300"><Wrench className="h-4 w-4" /> Garage</div>
                <h3 className="font-display text-3xl text-white">{garage.name}</h3>
              </div>
              <button onClick={() => engineRef.current?.closeGaragePublic()} className="touch-btn grid h-10 w-10 place-items-center rounded-xl" aria-label="Close garage"><X className="h-5 w-5" /></button>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {VEHICLES.map((spec) => {
                const active = spec.key === customVehicleKey;
                return (
                  <button
                    key={spec.key}
                    onClick={() => {
                      setCustomVehicleKey(spec.key);
                      engineRef.current?.setPlayerVehicle(spec.key, customColor);
                    }}
                    className={`flex flex-col items-start gap-1 rounded-2xl border p-3 text-left transition-all ${active ? 'border-amber-400 bg-amber-400/15 shadow-lg shadow-amber-900/30' : 'border-white/10 bg-white/5 hover:border-amber-300/40 hover:bg-white/10'}`}
                  >
                    <div className="flex w-full items-center justify-between">
                      <span className="font-semibold text-white">{spec.name}</span>
                      {active && <Check className="h-4 w-4 text-amber-300" />}
                    </div>
                    <span className="text-[10px] uppercase tracking-wider text-white/50">{spec.class}</span>
                    <span className="text-[11px] font-semibold text-amber-200">{spec.topSpeed} km/h · {spec.desc}</span>
                  </button>
                );
              })}
            </div>
            <div className="mt-5">
              <div className="mb-2 text-[10px] font-bold uppercase tracking-[0.3em] text-white/50">Paint</div>
              <div className="flex flex-wrap gap-2">
                {VEHICLE_COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => {
                      setCustomColor(c);
                      engineRef.current?.setPlayerVehicle(customVehicleKey as VehicleKey, c);
                    }}
                    className={`h-9 w-9 rounded-full border-2 transition-transform hover:scale-110 ${customColor === c ? 'border-amber-400 ring-2 ring-amber-400/40' : 'border-white/25'}`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>
            <button
              onClick={() => engineRef.current?.closeGaragePublic()}
              className="btn-gold mt-5 w-full rounded-2xl py-3 text-sm uppercase tracking-widest"
            >
              Done — Head out
            </button>
          </div>
        </div>
      )}

      {/* ── Pause modal ── */}
      {paused && !result && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/70 p-4 backdrop-blur-md">
          <div className="glass w-full max-w-md rounded-3xl p-7 text-center">
            <div className="font-display text-4xl tracking-wide text-amber-300">PAUSED</div>
            <p className="mt-1 text-xs uppercase tracking-[0.28em] text-white/50">{mode === 'tour' ? 'Grand Tour' : 'Free Roam'} · {formatHour(hud?.hour ?? 9.5)}</p>
            <div className="mt-4 grid grid-cols-3 gap-2">
              <div className="rounded-2xl bg-white/5 px-2 py-3"><div className="font-display text-2xl text-amber-200">{(hud?.score ?? 0).toLocaleString()}</div><div className="text-[9px] uppercase tracking-widest text-white/45">Score</div></div>
              <div className="rounded-2xl bg-white/5 px-2 py-3"><div className="font-display text-2xl text-emerald-300">{hud?.discovered ?? 0}/{hud?.total ?? 0}</div><div className="text-[9px] uppercase tracking-widest text-white/45">Cities</div></div>
              <div className="rounded-2xl bg-white/5 px-2 py-3"><div className="font-display text-2xl text-white">{hud?.distanceKm.toFixed(1) ?? '0'}</div><div className="text-[9px] uppercase tracking-widest text-white/45">Km</div></div>
            </div>
            <div className="mt-5 grid gap-2">
              <button onClick={togglePause} className="btn-gold flex items-center justify-center gap-2 rounded-2xl py-3 text-sm uppercase tracking-widest"><Play className="h-4 w-4 fill-current" /> Resume</button>
              <button onClick={onRestart} className="btn-ghost flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold uppercase tracking-widest"><RotateCcw className="h-4 w-4" /> Instant Restart</button>
              <button onClick={onExit} className="btn-ghost flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-semibold uppercase tracking-widest"><Home className="h-4 w-4" /> Quit to Menu</button>
            </div>
            <div className="mt-4 rounded-2xl bg-white/5 px-4 py-3 text-left">
              <div className="mb-1 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.25em] text-white/45"><Trophy className="h-3.5 w-3.5 text-amber-400" /> Top Scores</div>
              {scores.slice(0, 3).map((s, i) => (
                <div key={i} className="flex items-center justify-between py-1 text-sm"><span className="text-white/70">{i + 1}. {s.initials}</span><span className="font-semibold text-amber-200">{s.score.toLocaleString()}</span></div>
              ))}
              {scores.length === 0 && <div className="py-1 text-xs text-white/40">No scores recorded yet</div>}
            </div>
          </div>
        </div>
      )}

      {/* ── Game Over modal ── */}
      {result && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/75 p-4 backdrop-blur-md overflow-y-auto">
          <div className="glass my-auto w-full max-w-2xl rounded-3xl p-6 sm:p-8">
            <div className="text-center">
              <div className="text-[10px] font-bold uppercase tracking-[0.32em] text-amber-300">{mode === 'tour' ? 'Tour Complete' : 'Shift Ended'}</div>
              <h2 className="font-display mt-1 text-5xl tracking-wide text-white">{result.citiesFound === result.totalCities ? 'ALL CLEARED' : 'SHIFT OVER'}</h2>
              {newHighScore && (
                <div className="mx-auto mt-3 inline-flex items-center gap-2 rounded-full bg-amber-400 px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-amber-950">
                  <Trophy className="h-4 w-4" /> New High Score
                </div>
              )}
            </div>
            <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {[
                { icon: Sparkles, label: 'Score', value: result.score.toLocaleString() },
                { icon: MapPin, label: 'Cities', value: `${result.citiesFound}/${result.totalCities}` },
                { icon: Gauge, label: 'Distance', value: `${result.distanceKm.toFixed(1)} km` },
                { icon: Wind, label: 'Top Speed', value: `${result.topSpeedKmh} km/h` },
              ].map((s) => (
                <div key={s.label} className="rounded-2xl bg-white/5 px-3 py-4 text-center">
                  <s.icon className="mx-auto mb-1 h-4 w-4 text-amber-300" />
                  <div className="font-display text-2xl text-white">{s.value}</div>
                  <div className="text-[9px] font-semibold uppercase tracking-widest text-white/45">{s.label}</div>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-2xl bg-white/5 p-4">
              <div className="mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.25em] text-white/50"><Trophy className="h-3.5 w-3.5 text-amber-400" /> High Scores</div>
              <div className="space-y-1">
                {scores.slice(0, 5).map((s, i) => (
                  <div key={i} className="flex items-center justify-between rounded-xl bg-black/25 px-3 py-1.5 text-sm">
                    <span className="flex items-center gap-2 text-white/75"><span className={`font-display w-6 text-center text-lg ${i === 0 ? 'text-amber-300' : 'text-white/45'}`}>{i + 1}</span>{s.initials}</span>
                    <span className="text-xs text-white/45">{s.cities}/{s.total} cities · {s.km.toFixed(1)} km</span>
                    <span className="font-semibold text-amber-200">{s.score.toLocaleString()}</span>
                  </div>
                ))}
                {scores.length === 0 && <div className="py-2 text-center text-xs text-white/40">No scores recorded</div>}
              </div>
            </div>
            <div className="mt-5 grid grid-cols-2 gap-3">
              <button onClick={onRestart} className="btn-gold flex items-center justify-center gap-2 rounded-2xl py-3.5 text-sm uppercase tracking-widest"><RotateCcw className="h-4 w-4" /> Instant Restart</button>
              <button onClick={onExit} className="btn-ghost flex items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-semibold uppercase tracking-widest"><Home className="h-4 w-4" /> Main Menu</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
