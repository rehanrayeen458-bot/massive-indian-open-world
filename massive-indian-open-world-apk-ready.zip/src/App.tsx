import { useCallback, useEffect, useState } from 'react';
import Menu, { loadCustom, type CharacterCustom } from './screens/Menu';
import Game from './screens/Game';

type Screen = 'menu' | 'game';

export default function App() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [mode, setMode] = useState<'tour' | 'free'>('tour');
  const [character, setCharacter] = useState<CharacterCustom>(loadCustom);
  const [runId, setRunId] = useState(0);

  const startGame = useCallback((m: 'tour' | 'free') => {
    setCharacter(loadCustom());
    setMode(m);
    setRunId((i) => i + 1);
    setScreen('game');
  }, []);

  const exitToMenu = useCallback(() => setScreen('menu'), []);
  const restart = useCallback(() => setRunId((i) => i + 1), []);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
  }, []);

  return (
    <div className="h-full w-full overflow-hidden bg-[#05070f] text-white">
      {screen === 'menu' ? (
        <Menu onStart={startGame} />
      ) : (
        <Game
          key={runId}
          mode={mode}
          character={character}
          onExit={exitToMenu}
          onRestart={restart}
        />
      )}
    </div>
  );
}
